"""Tests for choral_read.py using small MusicXML files written here, each with a known right answer."""
import sys, json, zipfile, io, os, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import choral_read as R

FAILS = []
def ck(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else "  " + str(detail)[:300]))
    if not ok: FAILS.append(name)

HEAD = '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 3.1 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">\n'
def note(step, octv, dur, voice=1, lyric=None, syl="single", tie=None, chord=False, alter=0, staff=None, extra_lyr=None):
    t = ''.join('<tie type="%s"/>' % x for x in ([tie] if isinstance(tie, str) else (tie or [])))
    l = ''
    if lyric: l += '<lyric number="1"><syllabic>%s</syllabic><text>%s</text></lyric>' % (syl, lyric)
    for k, (tx, sy) in (extra_lyr or {}).items(): l += '<lyric number="%s"><syllabic>%s</syllabic><text>%s</text></lyric>' % (k, sy, tx)
    a = '<alter>%d</alter>' % alter if alter else ''
    st = '<staff>%d</staff>' % staff if staff else ''
    return '<note>%s<pitch><step>%s</step>%s<octave>%d</octave></pitch><duration>%d</duration>%s<voice>%d</voice>%s%s</note>' % ('<chord/>' if chord else '', step, a, octv, dur, t, voice, st, l)
def rest(dur, voice=1): return '<note><rest/><duration>%d</duration><voice>%d</voice></note>' % (dur, voice)
def measure(n, body, attrs='', extra='', implicit=False):
    return '<measure number="%s"%s>%s%s%s</measure>' % (n, ' implicit="yes"' if implicit else '', attrs, extra, body)
def attrs(div=1, fifths=0, beats=4, bt=4, clef=('G', 2, None), staves=None, transpose=None):
    c = '<clef><sign>%s</sign><line>%d</line>%s</clef>' % (clef[0], clef[1], '<clef-octave-change>%s</clef-octave-change>' % clef[2] if clef[2] else '')
    return '<attributes><divisions>%d</divisions><key><fifths>%d</fifths></key><time><beats>%d</beats><beat-type>%d</beat-type></time>%s</attributes>' % (div, fifths, beats, bt, c)
def score(parts, names):
    pl = ''.join('<score-part id="P%d"><part-name>%s</part-name></score-part>' % (i + 1, n) for i, n in enumerate(names))
    body = ''.join('<part id="P%d">%s</part>' % (i + 1, p) for i, p in enumerate(parts))
    return (HEAD + '<score-partwise version="3.1"><work><work-title>Test</work-title></work><part-list>%s</part-list>%s</score-partwise>' % (pl, body)).encode()
REP_F = '<barline location="left"><bar-style>heavy-light</bar-style><repeat direction="forward"/></barline>'
REP_B = '<barline location="right"><bar-style>light-heavy</bar-style><repeat direction="backward"/></barline>'
def END_START(n): return '<barline location="left"><ending number="%s" type="start"/></barline>' % n
def END_STOP(n, rep=False): return '<barline location="right"><ending number="%s" type="stop"/>%s</barline>' % (n, '<repeat direction="backward"/>' if rep else '')
def bar4(n, step='C', **kw): return measure(n, note(step, 4, 4, **kw), **{k: v for k, v in kw.items() if k in ('attrs','extra')})
def conv(x, **kw): return R.convert_musicxml(x, **kw)

# 1 plain repeat
x = score([measure(1, note('C',4,4,lyric='a'), attrs=attrs()) + measure(2, note('D',4,4), extra=REP_B) + measure(3, note('E',4,4))], ['Soprano'])
m = conv(x); ck('simple repeat -> 1 2 1 2 3', m.get('playOrder') == [0,1,0,1,2], m.get('playOrder'))
# 2 repeat with forward mark in the middle
x = score([measure(1, note('C',4,4), attrs=attrs()) + measure(2, note('D',4,4), extra=REP_F) + measure(3, note('E',4,4), extra=REP_B) + measure(4, note('F',4,4))], ['Soprano'])
m = conv(x); ck('repeat from bar 2', m.get('playOrder') == [0,1,2,1,2,3], m.get('playOrder'))
# 3 first and second endings
x = score([measure(1, note('C',4,4), attrs=attrs(), extra=REP_F) + measure(2, note('D',4,4), extra=END_START('1')+END_STOP('1', True)) + measure(3, note('E',4,4), extra=END_START('2')+END_STOP('2')) + measure(4, note('F',4,4))], ['Soprano'])
m = conv(x); ck('first/second endings -> 1 2 1 3 4', m.get('playOrder') == [0,1,0,2,3], m.get('playOrder'))
# 4 three verses, endings 1,2 and 3
x = score([measure(1, note('C',4,4), attrs=attrs(), extra=REP_F) + measure(2, note('D',4,4), extra=END_START('1, 2')+END_STOP('1, 2', True)) + measure(3, note('E',4,4), extra=END_START('3')+END_STOP('3')) ], ['Soprano'])
x = x.replace(b'<repeat direction="backward"/>', b'<repeat direction="backward" times="3"/>')
m = conv(x); ck('three passes, volta 1,2 then 3', m.get('playOrder') == [0,1,0,1,0,2], m.get('playOrder'))
# 5 D.C. al fine
x = score([measure(1, note('C',4,4), attrs=attrs()) + measure(2, note('D',4,4), extra='<direction><direction-type><words>Fine</words></direction-type><sound fine="yes"/></direction>') + measure(3, note('E',4,4), extra='<direction><direction-type><words>D.C. al Fine</words></direction-type><sound dacapo="yes"/></direction>')], ['Soprano'])
m = conv(x); ck('D.C. al Fine -> 1 2 3 1 2', m.get('playOrder') == [0,1,2,0,1], m.get('playOrder'))
# 6 D.S. al coda
x = score([measure(1, note('C',4,4), attrs=attrs()) + measure(2, note('D',4,4), extra='<direction><direction-type><segno/></direction-type><sound segno="s"/></direction>') + measure(3, note('E',4,4), extra='<direction><direction-type><words>To Coda</words></direction-type><sound tocoda="c"/></direction>') + measure(4, note('F',4,4), extra='<direction><direction-type><words>D.S. al Coda</words></direction-type><sound dalsegno="s"/></direction>') + measure(5, note('G',4,4), extra='<direction><direction-type><coda/></direction-type><sound coda="c"/></direction>')], ['Soprano'])
m = conv(x); ck('D.S. al Coda -> 1 2 3 4 2 3 5', m.get('playOrder') == [0,1,2,3,1,2,4], m.get('playOrder'))
# 7 pick-up bar and printed numbers
pick = measure(0, note('G',4,2) , attrs=attrs(div=2), implicit=True)
x = score([pick + measure(1, note('C',5,8)) + measure(2, note('C',5,8))], ['Soprano'])
m = conv(x); ck('pick-up: bar labels start at 0', (m.get('barLabels') or [])[:3] == ['0','1','2'], m.get('barLabels'))
ck('pick-up: bar starts are real', m['barStarts'][:3] == [0.0, 1.0, 5.0], m['barStarts'])
# 8 metre change
x = score([measure(1, note('C',4,4), attrs=attrs()) + measure(2, note('D',4,3), attrs='<attributes><time><beats>3</beats><beat-type>4</beat-type></time></attributes>')], ['Soprano'])
m = conv(x); ck('metre change recorded', m.get('meters') and m['meters'][1]['bar'] == 1 and m['meters'][1]['beats'] == 3, m.get('meters'))
ck('metre change: bar starts follow it', m['barStarts'] == [0.0, 4.0, 7.0], m['barStarts'])
# 9 key change
x = score([measure(1, note('C',4,4), attrs=attrs()) + measure(2, note('D',4,4), attrs='<attributes><key><fifths>-2</fifths></key></attributes>')], ['Soprano'])
m = conv(x); ck('key change recorded', m.get('keys') and m['keys'][1] == {'bar': 1, 'fifths': -2}, m.get('keys'))
# 10 SATB on two staves in one part (voices 1,2 / 5,6)
two = measure(1, note('E',5,4,1,'Ky',staff=1) + '<backup><duration>4</duration></backup>' + note('C',5,4,2,staff=1) + '<backup><duration>4</duration></backup>' + note('G',3,4,5,staff=2) + '<backup><duration>4</duration></backup>' + note('C',3,4,6,staff=2),
              attrs='<attributes><divisions>1</divisions><key><fifths>0</fifths></key><time><beats>4</beats><beat-type>4</beat-type></time><staves>2</staves><clef number="1"><sign>G</sign><line>2</line></clef><clef number="2"><sign>F</sign><line>4</line></clef></attributes>')
m = conv(score([two], ['Choir']))
ck('SATB on two staves -> 4 lines S A T B', [p['name'] for p in m['parts']] == ['Soprano','Alto','Tenor','Bass'], [p['name'] for p in m['parts']])
ck('voice letters', [p.get('voice') for p in m['parts']] == list('SATB'), [p.get('voice') for p in m['parts']])
ck('words shared with the lines that move together', all(p['notes'][0].get('lyric') == 'Ky' for p in m['parts']), [p['notes'][0] for p in m['parts']])
# 11 divisi chords
dv = measure(1, note('E',5,4,lyric='a') + note('C',5,4,chord=True) + note('F',5,4,lyric='b') + note('D',5,4,chord=True), attrs=attrs())
m = conv(score([dv], ['Soprano']))
ck('divisi chords -> two lines', len(m['parts']) == 2 and m['parts'][0]['name'] != m['parts'][1]['name'], [p['name'] for p in m['parts']])
ck('divisi: top and bottom notes', m['parts'][0]['notes'][0]['midi'] == 76 and m['parts'][1]['notes'][0]['midi'] == 72, [p['notes'][0] for p in m['parts']])
# 12 names: renaissance
S = measure(1, note('C',5,4), attrs=attrs()); A = measure(1, note('A',4,4), attrs=attrs()); T = measure(1, note('E',4,4), attrs=attrs(clef=('G',2,'-1'))); B = measure(1, note('C',3,4), attrs=attrs(clef=('F',4,None)))
m = conv(score([B, T, A, S], ['Bassus', 'Tenor', 'Altus', 'Cantus']))
ck('Cantus Altus Tenor Bassus -> S A T B in order', [p.get('voice') for p in m['parts']] == list('SATB') and [p['name'] for p in m['parts']] == ['Cantus','Altus','Tenor','Bassus'], [(p['name'], p.get('voice')) for p in m['parts']])
m = conv(score([S, A, T, B], ['Voice 1', 'Voice 2', 'Voice 3', 'Voice 4']))
ck('unnamed voices named by pitch', [p['name'] for p in m['parts']] == ['Soprano','Alto','Tenor','Bass'], [p['name'] for p in m['parts']])
# 13 Tenor 1 / Tenor 2 / S A B five voices
parts = [measure(1, note(s,o,4), attrs=attrs()) for s,o in (('C',5),('A',4),('E',4),('D',4),('C',3))]
m = conv(score(parts, ['S','A','T1','T2','B']))
ck('five parts keep their names', [p['name'] for p in m['parts']] == ['S','A','T1','T2','B'] and [p.get('voice') for p in m['parts']] == list('SATTB'), [(p['name'], p.get('voice')) for p in m['parts']])
# 14 verses
vs = measure(1, note('C',4,4,lyric='Glo',syl='begin',extra_lyr={'2': ('Sing','begin')}) + note('D',4,4,lyric='ry',syl='end',extra_lyr={'2': ('ing','end')}), attrs=attrs())
m = conv(score([vs], ['Soprano']))
n0 = m['parts'][0]['notes'][0]
ck('second verse kept', n0.get('v') == {'2': 'Sing-'} and m['verses'] == 2, (n0, m.get('verses')))
# 15 tempo
x = score([measure(1, note('C',4,4), attrs=attrs(), extra='<direction><direction-type><metronome><beat-unit>half</beat-unit><per-minute>60</per-minute></metronome></direction-type></direction>')], ['Soprano'])
m = conv(x); ck('metronome half=60 -> 120 quarter beats a minute', m['tempo'] == 120 and m['tempoSource'] == 'score', (m['tempo'], m.get('tempoSource')))
x = score([measure(1, note('C',4,4), attrs=attrs(), extra='<direction><direction-type><words>Andante con moto</words></direction-type></direction>')], ['Soprano'])
m = conv(x); ck('tempo word Andante', m['tempoSource'] == 'word' and m['tempo'] == 76, (m['tempo'], m.get('tempoSource')))
m = conv(score([measure(1, note('C',4,4), attrs=attrs())], ['Soprano'])); ck('no tempo -> labelled guess', m['tempoSource'] == 'guess')
# 16 bars of different lengths between parts do not drift
p1 = measure(1, note('C',4,4), attrs=attrs()) + measure(2, note('D',4,4)) + measure(3, note('E',4,4))
p2 = measure(1, note('C',4,3), attrs=attrs()) + measure(2, note('D',4,4)) + measure(3, note('E',4,4))   # short first bar by mistake
m = conv(score([p1, p2], ['Soprano', 'Alto']))
ck('a short bar in one part does not shift the others', m['parts'][1]['notes'][1]['start'] == 4.0, m['parts'][1]['notes'])
# 17 ties across barlines
tt = measure(1, note('C',4,4,tie='start'), attrs=attrs()) + measure(2, note('C',4,4,tie='stop'))
m = conv(score([tt], ['Soprano'])); ck('tie across barline joined', len(m['parts'][0]['notes']) == 1 and m['parts'][0]['notes'][0]['duration'] == 8.0, m['parts'][0]['notes'])
# 18 timewise, utf-16, bytes before prolog, mxl zip
tw = (HEAD + '<score-timewise version="3.1"><part-list><score-part id="P1"><part-name>Soprano</part-name></score-part></part-list><measure number="1"><part id="P1">' + attrs() + note('C',4,4) + '</part></measure></score-timewise>').encode()
m = conv(tw); ck('score-timewise read', len(m['parts']) == 1 and m['parts'][0]['notes'][0]['midi'] == 60)
u16 = ('﻿' + score([measure(1, note('C',4,4), attrs=attrs())], ['Soprano']).decode()).encode('utf-16')
m = conv(u16); ck('UTF-16 read', len(m['parts']) == 1)
m = conv(b'\n\n  junk ' + score([measure(1, note('C',4,4), attrs=attrs())], ['Soprano'])); ck('junk before <?xml tolerated', len(m['parts']) == 1)
buf = io.BytesIO()
with zipfile.ZipFile(buf, 'w') as z:
    z.writestr('META-INF/container.xml', '<container><rootfiles><rootfile full-path="s.xml"/></rootfiles></container>')
    z.writestr('s.xml', score([measure(1, note('C',4,4), attrs=attrs())], ['Soprano']))
with tempfile.NamedTemporaryFile(suffix='.mxl', delete=False) as f: f.write(buf.getvalue()); pth = f.name
m = conv(pth); ck('.mxl zip read', len(m['parts']) == 1); os.unlink(pth)
# 19 transposing part (treble8 via transpose)
tr = measure(1, note('C',5,4), attrs='<attributes><divisions>1</divisions><key><fifths>0</fifths></key><time><beats>4</beats><beat-type>4</beat-type></time><clef><sign>G</sign><line>2</line></clef><transpose><diatonic>0</diatonic><chromatic>0</chromatic><octave-change>-1</octave-change></transpose></attributes>')
m = conv(score([tr], ['Tenor'])); ck('transposing tenor sounds an octave lower', m['parts'][0]['notes'][0]['midi'] == 60 and m['parts'][0].get('clef') == 'treble8', m['parts'][0])
# 20 piano accompaniment kept apart from voices
pa = measure(1, note('C',4,4), attrs=attrs()); m = conv(score([pa, pa], ['Soprano', 'Piano']))
ck('piano is accompaniment', [p['role'] for p in m['parts']] == ['voice', 'accompaniment'], [(p['name'], p['role']) for p in m['parts']])
# 21 breve metre displays halved
bm = measure(1, note('C',4,8), attrs=attrs(beats=2, bt=1)); m = conv(score([bm], ['Soprano']))
ck('2/1 shown as 2/2 with values halved', m.get('display','{}')['scale'] == 0.5 and m['display']['meter'] == {'beats': 2, 'beatType': 2} and m['display']['tempo'] == m['tempo']*0.5, m.get('display'))
# 22 warnings for a bad bar
bad = measure(1, note('C',4,4), attrs=attrs()) + measure(2, note('D',4,3)) + measure(3, note('E',4,4))
m = conv(score([bad], ['Soprano'])); ck('odd bar length is reported', any('not the length' in w for w in m['warnings']), m['warnings'])
# 23 range check
hi = measure(1, note('C',6,4), attrs=attrs(clef=('F',4,None))); m = conv(score([hi], ['Bass']))
ck('bass note far too high is reported', any('outside the usual range' in w for w in m['warnings']), m['warnings'])
# 24 which part/bar looks wrong is listed (what a proofreading screen needs)
sa = measure(1, note('C',4,4), attrs=attrs()) + measure(2, note('D',4,4)) + measure(3, note('E',4,4)) + measure(4, note('F',4,4))
sb = measure(1, note('C',4,4), attrs=attrs()) + measure(2, note('D',4,3)) + measure(3, note('E',4,4)) + measure(4, note('F',4,4))
m = conv(score([sa, sb], ['Soprano', 'Alto']))
ck('misread bar is listed with its part', m.get('check') == [{'bar': 1, 'part': 'Alto', 'found': 3.0, 'expected': 4.0, 'kind': 'length'}], m.get('check'))
print('\n%d failed' % len(FAILS))
sys.exit(1 if FAILS else 0)
