#!/usr/bin/env python3
"""
ly_reader.py - a LilyPond (.ly) reader for choral_build.py.  Standard library only.

It understands the part of LilyPond that choral editions actually use:
  notes (nederlands / deutsch / english names), rests, R, s, \\skip, durations, dots, *multipliers,
  \\relative, \\absolute, \\transpose, ties, slurs, chords (top note kept later),
  \\repeat unfold|volta + \\alternative, \\times, \\tuplet, \\grace (ignored), \\partial,
  \\key, \\time, \\tempo, \\clef, \\set Score.measureLength, \\set Staff.instrumentName,
  variables (\\name = ..., used later as \\name; redefinition between \\score blocks works),
  \\new Staff / Voice, << a \\\\ b >> voices, \\lyricmode / \\lyricsto / \\addlyrics
  (syllables, hyphens `--`, melisma `_` and `__`, slurs and ties), several \\score blocks
  (joined one after another, e.g. Prima / Secunda pars).

What it does NOT do (it says so in warnings instead of guessing):
  \\include of other files, \\book layouts that duplicate the music, scheme-defined music,
  figured bass, chord names, percent/tremolo repeats, cadenza mode.

parse_lilypond(text) returns (info, parts) in the same shape as choral_build.parse_musicxml.
"""
import re
from fractions import Fraction

STEP_SEMI = [0, 2, 4, 5, 7, 9, 11]
LETTERS = "cdefgab"
LOF = {0: 0, 1: 2, 2: 4, 3: -1, 4: 1, 5: 3, 6: 5}           # line-of-fifths of natural tonics
MODES = {"major": 0, "ionian": 0, "minor": -3, "aeolian": -3, "dorian": -2, "phrygian": -4,
         "lydian": 1, "mixolydian": -1, "locrian": -5}

NOARG = set("""stemUp stemDown stemNeutral autoBeamOn autoBeamOff break noBreak pageBreak noPageBreak
lineBreak noLineBreak fermata p pp ppp pppp f ff fff ffff mp mf fp sf sfz sff rfz cresc decr dim espressivo
accent marcato staccato staccatissimo tenuto portato trill turn prall mordent downbow upbow open stopped
flageolet thumb arpeggio glissando oneVoice voiceOne voiceTwo voiceThree voiceFour shiftOn shiftOff shiftOnn
slurUp slurDown slurNeutral dotsUp dotsDown dotsNeutral tieUp tieDown tieNeutral phrasingSlurUp phrasingSlurDown
numericTimeSignature defaultTimeSignature cadenzaOn cadenzaOff once bendAfter easyHeadsOn easyHeadsOff
dynamicUp dynamicDown dynamicNeutral textLengthOn textLengthOff teeny tiny small normalsize large huge
sustainOn sustainOff unHideNotes hideNotes harmonic repeatTie laissezVibrer default newpage
stopStaff startStaff partcombineApart partcombineChords xNotesOn xNotesOff improvisationOn improvisationOff
bar_ undo hide omit footnote""".split())
ARG1 = set("""bar mark accidentalStyle ottava transposition shape tag keepWithTag removeWithTag
incipit grace_ footnote_ cueDuring quoteDuring clef_ set_unused""".split())
GRACE = {"grace", "acciaccatura", "appoggiatura", "slashedGrace"}
GROUP_CTX = {"ChoirStaff", "StaffGroup", "GrandStaff", "PianoStaff", "Score", "Global"}
IGNORE_CTX = {"ChordNames", "FretBoards", "Dynamics", "FiguredBass", "Devnull", "NoteNames", "TabStaff",
              "TabVoice", "DrumStaff", "DrumVoice", "RhythmicStaff"}
RENAISSANCE = {"cantus": "Soprano (Cantus)", "superius": "Soprano (Superius)", "discantus": "Soprano (Discantus)",
               "canto": "Soprano (Canto)", "altus": "Alto (Altus)", "contratenor": "Alto (Contratenor)",
               "tenor": "Tenor", "bassus": "Bass (Bassus)", "basso": "Bass (Basso)", "quintus": "Quintus",
               "sextus": "Sextus", "vagans": "Vagans"}


class LyError(Exception):
    pass


# --------------------------------------------------------------------------------------------
# tokenizer
# --------------------------------------------------------------------------------------------
def _capture_block(src, i):
    """src[i] == '{'. Return (text without comments, index after the matching '}')."""
    depth, j, n, out = 0, i, len(src), []
    while j < n:
        c = src[j]
        if c == "%":
            if src.startswith("%{", j):
                k = src.find("%}", j + 2)
                j = n if k < 0 else k + 2
            else:
                k = src.find("\n", j)
                j = n if k < 0 else k
            continue
        if c == '"':
            k = j + 1
            while k < n and src[k] != '"':
                k += 2 if src[k] == "\\" else 1
            out.append(src[j:k + 1])
            j = k + 1
            continue
        if c == "{":
            depth += 1
            if depth > 1:
                out.append(c)
        elif c == "}":
            depth -= 1
            if depth == 0:
                return "".join(out), j + 1
            out.append(c)
        else:
            out.append(c)
        j += 1
    raise LyError("unbalanced braces in lyrics")


def _scan_scheme(src, i, toks):
    n = len(src)
    j = i + 1
    if j < n and src[j] == "'" and j + 1 < n and src[j + 1] == "(":
        j += 1
    if j < n and src[j] == "(":
        depth = 0
        while j < n:
            c = src[j]
            if c == '"':
                k = j + 1
                while k < n and src[k] != '"':
                    k += 2 if src[k] == "\\" else 1
                j = k
            elif c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
                if depth == 0:
                    j += 1
                    break
            j += 1
        toks.append(("sch", src[i:j]))
        return j
    if j < n and src[j] == "{":
        k = src.find("#}", j)
        k = n if k < 0 else k + 2
        toks.append(("sch", src[i:k]))
        return k
    while j < n and not src[j].isspace() and src[j] not in "}>)":
        j += 1
    toks.append(("sch", src[i:j]))
    return j


CMD_RE = re.compile(r"\\([A-Za-z]+)")
WORD_RE = re.compile(r"[A-Za-z]+")
NUM_RE = re.compile(r"\d+")


def tokenize(src):
    toks, i, n = [], 0, len(src)
    want_lyr = False          # after \lyricsto "x" the next { is a lyrics block
    while i < n:
        c = src[i]
        if c.isspace():
            i += 1
            continue
        if c == "%":
            if src.startswith("%{", i):
                k = src.find("%}", i + 2)
                i = n if k < 0 else k + 2
            else:
                k = src.find("\n", i)
                i = n if k < 0 else k + 1
            continue
        if c == '"':
            j = i + 1
            while j < n and src[j] != '"':
                j += 2 if src[j] == "\\" else 1
            toks.append(("str", src[i + 1:j]))
            i = j + 1
            if want_lyr:
                want_lyr = False
                k = i
                while k < n and src[k].isspace():
                    k += 1
                if k < n and src[k] == "{":
                    text, i = _capture_block(src, k)
                    toks.append(("lyr", text))
            continue
        if c == "#":
            i = _scan_scheme(src, i, toks)
            continue
        if c == "\\":
            m = CMD_RE.match(src, i)
            if m:
                name = m.group(1)
                i = m.end()
                if name in ("lyricmode", "lyrics", "addlyrics"):
                    k = i
                    while k < n and src[k].isspace():
                        k += 1
                    if k < n and src[k] == "{":
                        text, i = _capture_block(src, k)
                        if name == "addlyrics":
                            toks.append(("cmd", "addlyrics"))
                        toks.append(("lyr", text))
                        continue
                if name == "lyricsto":
                    want_lyr = True
                toks.append(("cmd", name))
                continue
            if src.startswith("\\\\", i):
                toks.append(("op", "\\\\"))
                i += 2
                continue
            toks.append(("op", src[i:i + 2]))
            i += 2
            continue
        if c.isalpha():
            m = WORD_RE.match(src, i)
            toks.append(("word", m.group(0)))
            i = m.end()
            continue
        if c.isdigit():
            m = NUM_RE.match(src, i)
            toks.append(("num", int(m.group(0))))
            i = m.end()
            continue
        if src.startswith("<<", i):
            toks.append(("op", "<<"))
            i += 2
            continue
        if src.startswith(">>", i):
            toks.append(("op", ">>"))
            i += 2
            continue
        toks.append(("op", c))
        i += 1
    return toks


# --------------------------------------------------------------------------------------------
# pitch helpers
# --------------------------------------------------------------------------------------------
def midi_of(p):
    step, alter, octv = p
    return 12 * (octv + 1) + STEP_SEMI[step] + alter


def name_to_pitch(word, lang):
    """word -> (step 0..6, alter) or None."""
    w = word
    if lang == "deutsch":
        if w == "b":
            return (6, -1)
        if w == "heses":
            return (6, -2)
        if w == "hes":
            return (6, -1)
        if w.startswith("h"):
            m = re.fullmatch(r"h((?:is)*)", w)
            return (6, len(m.group(1)) // 2) if m else None
        if w[:1] not in "cdefga":
            return None
        letter, rest = w[0], w[1:]
    elif lang == "english":
        m = re.fullmatch(r"([a-g])(s|ss|x|f|ff|sharp|flat)?", w)
        if not m:
            return None
        alt = {None: 0, "s": 1, "sharp": 1, "ss": 2, "x": 2, "f": -1, "flat": -1, "ff": -2}[m.group(2)]
        return (LETTERS.index(m.group(1)), alt)
    else:
        if w[:1] not in "abcdefg":
            return None
        letter, rest = w[0], w[1:]
    if rest == "":
        alter = 0
    elif re.fullmatch(r"(is)+", rest):
        alter = len(rest) // 2
    elif re.fullmatch(r"(es)+", rest):
        alter = -(len(rest) // 2)
    elif letter in "ea" and re.fullmatch(r"s(es)*", rest):
        alter = -(1 + (len(rest) - 1) // 2)
    else:
        return None
    return (LETTERS.index(letter), alter)


def transpose_pitch(p, frm, to):
    d = (to[2] * 7 + to[0]) - (frm[2] * 7 + frm[0])
    semis = midi_of(to) - midi_of(frm)
    diat = p[2] * 7 + p[0] + d
    octv, step = divmod(diat, 7)
    target = midi_of(p) + semis
    return (step, target - midi_of((step, 0, octv)), octv)


# --------------------------------------------------------------------------------------------
# parser / evaluator
# --------------------------------------------------------------------------------------------
class Parser:
    def __init__(self, toks):
        self.toks = toks
        self.vars = {}
        self.lang = "nederlands"
        self.scores = []
        self.warn = []
        self.title = None
        self.composer = None
        self.depth = 0
        self.dur = Fraction(1, 4)
        self.reset_score()

    # ---- state
    def reset_score(self):
        self.events, self.meta, self.ctxs, self.lyr_assign = [], [], [], []
        self.max_end = Fraction(0)
        self.root = self.new_ctx("Voice", None, None, implicit=True)
        self.ctx_stack = [self.root]
        self.scale = Fraction(1)
        self.rel = None
        self.trans = []
        self.mute = 0
        self.dur = Fraction(1, 4)
        self.last_notes = []

    def new_ctx(self, kind, name, parent, implicit=False):
        c = {"id": len(self.ctxs), "kind": kind, "name": name, "inst": None, "clef": None,
             "parent": parent, "implicit": implicit}
        self.ctxs.append(c)
        return c

    def warning(self, msg):
        if msg not in self.warn and len(self.warn) < 40:
            self.warn.append(msg)

    def tk(self, pos):
        return self.toks[pos] if pos < len(self.toks) else ("eof", None)

    def is_op(self, pos, v):
        t = self.tk(pos)
        return t[0] == "op" and t[1] == v

    # ---- skipping helpers
    def skip_balanced(self, pos):
        """pos at '{' or '<<'; return index after the matching close."""
        stack = []
        n = len(self.toks)
        while pos < n:
            t = self.toks[pos]
            if t[0] == "op":
                if t[1] in ("{", "<<"):
                    stack.append(t[1])
                elif t[1] in ("}", ">>"):
                    if stack:
                        stack.pop()
                    if not stack:
                        return pos + 1
            pos += 1
        raise LyError("unbalanced braces")

    def skip_arg(self, pos):
        t = self.tk(pos)
        if t[0] == "eof":
            return pos
        if t[0] == "op" and t[1] in ("{", "<<"):
            return self.skip_balanced(pos)
        if t[0] == "cmd" and t[1] in ("markup", "markuplist", "column", "line", "bold", "italic",
                                      "center-column", "concat", "fontsize", "hspace", "raise"):
            return self.skip_arg(pos + 1) if self.tk(pos + 1)[0] != "eof" else pos + 1
        return pos + 1

    def find_close(self, pos):
        """pos just after an opening '<<': does a '\\\\' occur at depth 0 before the closing '>>'?"""
        depth, n, found = 0, len(self.toks), False
        while pos < n:
            t = self.toks[pos]
            if t[0] == "op":
                if t[1] in ("{", "<<"):
                    depth += 1
                elif t[1] in ("}", ">>"):
                    if depth == 0:
                        return found
                    depth -= 1
                elif t[1] == "\\\\" and depth == 0:
                    found = True
            pos += 1
        return found

    # ---- emission
    def cur_ctx(self):
        return self.ctx_stack[-1]

    def emit(self, kind, t, dur, pitch=None):
        end = t + dur
        if self.mute:
            return None
        if end > self.max_end:
            self.max_end = end
        if kind == "s":
            return None
        ev = {"t": t, "d": dur, "k": kind, "p": pitch, "ctx": self.cur_ctx()["id"],
              "tie": False, "sl": None, "n": len(self.events)}
        self.events.append(ev)
        return ev

    def add_meta(self, t, kind, val):
        if not self.mute:
            self.meta.append((t, kind, val))

    def staff_ctx(self):
        c = self.cur_ctx()
        while c is not None:
            if c["kind"] == "Staff":
                return c
            c = c["parent"]
        return self.cur_ctx()

    def tr_pitch(self, p):
        for frm, to in reversed(self.trans):
            p = transpose_pitch(p, frm, to)
        return p

    # ---- durations
    def read_dur(self, pos):
        t = self.tk(pos)
        base = None
        if t[0] == "num":
            base = Fraction(1, t[1])
            pos += 1
        elif t[0] == "cmd" and t[1] in ("breve", "longa", "maxima"):
            base = Fraction({"breve": 2, "longa": 4, "maxima": 8}[t[1]])
            pos += 1
        if base is not None:
            dots = 0
            while self.is_op(pos, "."):
                dots += 1
                pos += 1
            self.dur = base * (2 - Fraction(1, 2 ** dots))
        mult = Fraction(1)
        while self.is_op(pos, "*"):
            a = self.tk(pos + 1)
            if a[0] != "num":
                break
            f = Fraction(a[1])
            pos += 2
            if self.is_op(pos, "/") and self.tk(pos + 1)[0] == "num":
                f /= self.tk(pos + 1)[1]
                pos += 2
            mult *= f
        return self.dur * mult * self.scale, pos

    # ---- pitches
    def read_marks(self, pos):
        up = 0
        while True:
            t = self.tk(pos)
            if t[0] == "op" and t[1] == "'":
                up += 1
            elif t[0] == "op" and t[1] == ",":
                up -= 1
            elif t[0] == "op" and t[1] in ("!", "?"):
                pass
            else:
                break
            pos += 1
        return up, pos

    def abs_pitch(self, pos):
        """Read an absolute pitch (used by \\relative, \\transpose, \\key). Unmarked c = C3."""
        t = self.tk(pos)
        if t[0] != "word":
            return None, pos
        np_ = name_to_pitch(t[1], self.lang)
        if np_ is None:
            return None, pos
        up, pos = self.read_marks(pos + 1)
        return (np_[0], np_[1], 3 + up), pos

    def resolve_pitch(self, step, alter, marks):
        if self.rel is not None:
            ref = self.rel
            x = ref[1] * 7 + ref[0] - step
            n = (x + 3) // 7
            octv = n + marks
        else:
            octv = 3 + marks
        p = (step, alter, octv)
        if self.rel is not None:
            self.rel = (step, octv)
            self.rel_alter = alter
        return p

    # ---- main item parser
    def parse_seq_until(self, pos, t0, closers):
        t = t0
        n = len(self.toks)
        while pos < n:
            tok = self.toks[pos]
            if tok[0] == "op" and tok[1] in closers:
                break
            l, pos = self.parse_item(pos, t)
            t += l
        return t - t0, pos

    def parse_item(self, pos, t0):
        n = len(self.toks)
        if pos >= n:
            return Fraction(0), pos
        tok = self.toks[pos]
        kind, val = tok

        if kind == "op":
            if val == "{":
                l, p = self.parse_seq_until(pos + 1, t0, ("}",))
                return l, p + 1
            if val == "<<":
                return self.parse_simul(pos, t0)
            if val == "<":
                return self.parse_chord(pos, t0)
            if val == "~":
                for ev in self.last_notes:
                    ev["tie"] = True
                return Fraction(0), pos + 1
            if val == "(":
                if self.last_notes:
                    self.last_notes[0]["sl"] = "s"
                return Fraction(0), pos + 1
            if val == ")":
                if self.last_notes:
                    self.last_notes[0]["sl"] = (self.last_notes[0]["sl"] or "") + "e"
                return Fraction(0), pos + 1
            if val in ("^", "_", "-"):
                nxt = self.tk(pos + 1)
                if nxt[0] in ("str", "word", "num", "cmd", "sch"):
                    return Fraction(0), self.skip_arg(pos + 1)
                if nxt[0] == "op" and nxt[1] in (".", ">", "-", "^", "+", "!", "_"):
                    return Fraction(0), pos + 2
                return Fraction(0), pos + 1
            if val in ("}", ">>"):
                return Fraction(0), pos + 1      # stray closer
            return Fraction(0), pos + 1          # | [ ] = . etc.

        if kind in ("str", "num", "sch", "lyr"):
            return Fraction(0), pos + 1

        if kind == "word":
            return self.parse_word(pos, t0)

        # kind == "cmd"
        return self.parse_cmd(pos, t0)

    # ---- simultaneous music
    def parse_simul(self, pos, t0):
        pos += 1
        n = len(self.toks)
        length = Fraction(0)
        if self.find_close(pos):
            staff = self.staff_ctx()
            while pos < n and not self.is_op(pos, ">>"):
                ctx = None
                if not self.mute:
                    ctx = self.new_ctx("Voice", None, staff)
                    self.ctx_stack.append(ctx)
                l, pos = self.parse_seq_until(pos, t0, (">>", "\\\\"))
                if ctx is not None:
                    self.ctx_stack.pop()
                length = max(length, l)
                if self.is_op(pos, "\\\\"):
                    pos += 1
        else:
            while pos < n and not self.is_op(pos, ">>"):
                l, pos = self.parse_item(pos, t0)
                length = max(length, l)
        return length, pos + 1

    # ---- notes
    def parse_word(self, pos, t0):
        w = self.toks[pos][1]
        if w in ("r", "R", "s", "S", "q", "M"):
            d, p = self.read_dur(pos + 1)
            if w in ("r", "R"):
                ev = self.emit("r", t0, d)
                self.last_notes = [ev] if ev else []
            elif w == "q":
                self.warning("chord repetition q not supported")
                self.emit("s", t0, d)
            else:
                self.emit("s", t0, d)
            return d, p
        np_ = name_to_pitch(w, self.lang)
        if np_ is None:
            self.warning("unknown word in music: %s" % w)
            return Fraction(0), pos + 1
        marks, p = self.read_marks(pos + 1)
        pitch = self.tr_pitch(self.resolve_pitch(np_[0], np_[1], marks))
        d, p = self.read_dur(p)
        ev = self.emit("n", t0, d, pitch)
        self.last_notes = [ev] if ev else []
        return d, p

    def parse_chord(self, pos, t0):
        pos += 1
        pitches, first_ref = [], None
        n = len(self.toks)
        saved_rel = self.rel
        while pos < n and not self.is_op(pos, ">"):
            t = self.toks[pos]
            if t[0] == "word":
                np_ = name_to_pitch(t[1], self.lang)
                if np_ is not None:
                    marks, pos2 = self.read_marks(pos + 1)
                    pitches.append(self.tr_pitch(self.resolve_pitch(np_[0], np_[1], marks)))
                    if first_ref is None:
                        first_ref = self.rel
                    pos = pos2
                    continue
            pos += 1
        pos += 1
        if saved_rel is not None and first_ref is not None:
            self.rel = first_ref
        d, pos = self.read_dur(pos)
        evs = []
        for p in pitches:
            ev = self.emit("n", t0, d, p)
            if ev:
                evs.append(ev)
        self.last_notes = evs
        return d, pos

    # ---- commands
    def parse_cmd(self, pos, t0):
        name = self.toks[pos][1]
        zero = Fraction(0)

        if name == "relative":
            pos += 1
            ref = None
            p, p2 = self.abs_pitch(pos)
            if p is not None:
                ref, pos = (p[0], p[2]), p2
            else:
                ref = (0, 4)
            saved = self.rel
            self.rel = ref
            l, pos = self.parse_item(pos, t0)
            self.rel = saved
            return l, pos
        if name == "absolute":
            saved = self.rel
            self.rel = None
            l, pos = self.parse_item(pos + 1, t0)
            self.rel = saved
            return l, pos
        if name == "transpose":
            a, pos2 = self.abs_pitch(pos + 1)
            b, pos2 = self.abs_pitch(pos2) if a else (None, pos2)
            if a is None or b is None:
                self.warning("could not read \\transpose pitches")
                return zero, pos + 1
            self.trans.append((a, b))
            l, pos2 = self.parse_item(pos2, t0)
            self.trans.pop()
            return l, pos2
        if name in ("new", "context"):
            return self.parse_new(pos, t0)
        if name == "with":
            return zero, self.skip_arg(pos + 1)
        if name == "lyricsto":
            return self.parse_lyricsto(pos)
        if name == "addlyrics":
            nxt = self.tk(pos + 1)
            raw = None
            p = pos + 1
            if nxt[0] == "lyr":
                raw, p = nxt[1], pos + 2
            elif nxt[0] == "cmd" and nxt[1] in self.vars:
                raw, p = self.var_lyrics(nxt[1]), pos + 2
            if raw is not None and not self.mute and self.last_notes:
                self.lyr_assign.append((self.last_notes[0]["ctx"], raw, "ctx"))
            return zero, p
        if name == "repeat":
            return self.parse_repeat(pos, t0)
        if name == "alternative":
            return self.parse_item(pos + 1, t0)
        if name in ("times", "tuplet"):
            pos += 1
            a, b = self.tk(pos), self.tk(pos + 2)
            if a[0] == "num" and self.is_op(pos + 1, "/") and b[0] == "num":
                f = Fraction(a[1], b[1]) if name == "times" else Fraction(b[1], a[1])
                pos += 3
                if name == "tuplet" and self.tk(pos)[0] == "num":
                    pos += 1
                saved = self.scale
                self.scale *= f
                l, pos = self.parse_item(pos, t0)
                self.scale = saved
                return l, pos
            self.warning("could not read tuplet ratio")
            return zero, pos
        if name in GRACE:
            self.mute += 1
            _, pos = self.parse_item(pos + 1, t0)
            self.mute -= 1
            return zero, pos
        if name == "partial":
            saved = self.dur
            d, pos = self.read_dur(pos + 1)
            self.dur = saved
            self.add_meta(t0, "partial", d)
            return zero, pos
        if name == "time":
            a, b = self.tk(pos + 1), self.tk(pos + 3)
            if a[0] == "num" and self.is_op(pos + 2, "/") and b[0] == "num":
                self.add_meta(t0, "barlen", (a[1], b[1]))
                return zero, pos + 4
            return zero, pos + 1
        if name == "key":
            p, p2 = self.abs_pitch(pos + 1)
            mode = self.tk(p2)
            if p is not None and mode[0] == "cmd" and mode[1] in MODES:
                tonic = self.tr_pitch(p)
                self.add_meta(t0, "fifths", LOF[tonic[0]] + 7 * tonic[1] + MODES[mode[1]])
                return zero, p2 + 1
            return zero, pos + 1
        if name == "clef":
            nxt = self.tk(pos + 1)
            if nxt[0] in ("str", "word", "cmd"):
                self.set_clef(str(nxt[1]))
                return zero, pos + 2
            return zero, pos + 1
        if name == "tempo":
            return self.parse_tempo(pos, t0)
        if name == "set":
            return self.parse_set(pos, t0)
        if name in ("override", "overrideProperty"):
            return zero, self.skip_override(pos + 1)
        if name in ("revert", "unset"):
            p = pos + 1
            while self.tk(p)[0] in ("word",) or (self.tk(p)[0] == "op" and self.tk(p)[1] in (".", "-")):
                p += 1
                if p - pos > 8:
                    break
            return zero, p
        if name == "skip":
            d, p = self.read_dur(pos + 1)
            self.emit("s", t0, d)
            return d, p
        if name in ("markup", "markuplist"):
            return zero, self.skip_arg(pos)
        if name == "tweak":
            p = pos + 1
            while p < len(self.toks) and self.tk(p)[0] in ("word", "op", "str") and not self.is_op(p, "{"):
                if self.tk(p)[0] == "op" and self.tk(p)[1] not in (".", "-"):
                    break
                p += 1
            return zero, self.skip_arg(p)
        if name in ARG1:
            return zero, self.skip_arg(pos + 1)
        if name in ("major", "minor"):
            return zero, pos + 1
        if name in self.vars:
            return self.use_var(name, pos, t0)
        if name in NOARG or name in ("breve", "longa"):
            return zero, pos + 1
        self.warning("unknown command \\%s" % name)
        return zero, pos + 1

    def set_clef(self, c):
        s = self.staff_ctx()
        cl = c.lower()
        if "_8" in cl or "8vb" in cl or "tenor" == cl and False:
            val = "treble8"
        elif "bass" in cl or cl.startswith("f") and "g" not in cl:
            val = "bass"
        elif "treble" in cl or "violin" in cl or cl.startswith("g") or "french" in cl:
            val = "treble"
        else:
            val = None
        if not self.mute and s["clef"] is None and not s.get("clef_set"):
            s["clef"] = val
            s["clef_set"] = True

    def parse_tempo(self, pos, t0):
        p = pos + 1
        while self.tk(p)[0] == "str":
            p += 1
        if self.tk(p)[0] == "cmd" and self.tk(p)[1] in ("markup",):
            p = self.skip_arg(p)
        a = self.tk(p)
        if a[0] == "num":
            q = p + 1
            dots = 0
            while self.is_op(q, "."):
                dots += 1
                q += 1
            if self.is_op(q, "=") and self.tk(q + 1)[0] == "num":
                bpm = self.tk(q + 1)[1]
                q += 2
                if self.is_op(q, "-") and self.tk(q + 1)[0] == "num":
                    q += 2
                unit = Fraction(1, a[1]) * (2 - Fraction(1, 2 ** dots))
                self.add_meta(t0, "tempo", float(bpm * unit * 4))
                return Fraction(0), q
        return Fraction(0), p

    def skip_override(self, pos):
        p, n = pos, len(self.toks)
        while p < n and p - pos < 24 and not self.is_op(p, "="):
            if self.tk(p)[0] == "sch":
                return p + 1
            p += 1
        if self.is_op(p, "="):
            return self.skip_arg(p + 1)
        return pos

    def parse_set(self, pos, t0):
        p, n = pos + 1, len(self.toks)
        path = []
        while p < n and p - pos < 12 and not self.is_op(p, "="):
            if self.tk(p)[0] == "word":
                path.append(self.tk(p)[1])
            p += 1
        if not self.is_op(p, "="):
            return Fraction(0), pos + 1
        p += 1
        prop = path[-1] if path else ""
        vt = self.tk(p)
        text = None
        if vt[0] == "str":
            text = vt[1]
            end = p + 1
        elif vt[0] == "cmd" and vt[1] == "markup":
            end = self.skip_arg(p)
            for q in range(p, end):
                if self.tk(q)[0] == "str":
                    text = self.tk(q)[1]
                    break
        elif vt[0] == "sch":
            text = vt[1]
            end = p + 1
        else:
            end = p + 1
        if prop in ("instrumentName",) and text:
            s = self.staff_ctx()
            if not self.mute and s["inst"] is None:
                s["inst"] = text
        elif prop == "measureLength" and text:
            m = re.search(r"make-moment\s+(\d+)\s*[/ ]\s*(\d+)", text)
            if m:
                self.add_meta(t0, "barlen", (int(m.group(1)), int(m.group(2))))
        return Fraction(0), end

    def parse_new(self, pos, t0):
        ctype = self.tk(pos + 1)
        pos += 2
        cname = None
        if self.is_op(pos, "=") and self.tk(pos + 1)[0] in ("str", "word"):
            cname = str(self.tk(pos + 1)[1])
            pos += 2
        if self.tk(pos)[0] == "cmd" and self.tk(pos)[1] == "with":
            pos = self.skip_arg(pos + 1)
        ct = ctype[1] if ctype[0] == "word" else ""
        if ct in GROUP_CTX:
            return self.parse_item(pos, t0)
        if ct in IGNORE_CTX or ct.endswith("Names"):
            self.mute += 1
            l, pos = self.parse_item(pos, t0)
            self.mute -= 1
            return Fraction(0), pos
        if ct in ("Lyrics", "LyricsContext", "NullVoice", "NullStaff"):
            self.mute += 1
            saved_assign = len(self.lyr_assign)
            self.mute -= 1
            l, pos = self.parse_lyric_context(pos, t0)
            return Fraction(0), pos
        if ct.endswith("Staff") or ct.endswith("Voice"):
            kind = "Staff" if ct.endswith("Staff") else "Voice"
            if self.mute:
                return self.parse_item(pos, t0)
            ctx = self.new_ctx(kind, cname, self.cur_ctx() if self.cur_ctx()["implicit"] is False else None)
            self.ctx_stack.append(ctx)
            l, pos = self.parse_item(pos, t0)
            self.ctx_stack.pop()
            return l, pos
        self.warning("unsupported context %s" % ct)
        return self.parse_item(pos, t0)

    def parse_lyric_context(self, pos, t0):
        """After \\new Lyrics: expect \\lyricsto "x" {...}, a lyrics block, or a braced mix."""
        t = self.tk(pos)
        if t[0] == "cmd" and t[1] == "lyricsto":
            return self.parse_lyricsto(pos)
        if t[0] == "op" and t[1] == "{":
            end = self.skip_balanced(pos)
            p = pos + 1
            while p < end - 1:
                if self.tk(p)[0] == "cmd" and self.tk(p)[1] == "lyricsto":
                    _, p = self.parse_lyricsto(p)
                else:
                    p += 1
            return Fraction(0), end
        if t[0] == "op" and t[1] == "<<":
            end = self.skip_balanced(pos)
            p = pos + 1
            while p < end - 1:
                if self.tk(p)[0] == "cmd" and self.tk(p)[1] == "lyricsto":
                    _, p = self.parse_lyricsto(p)
                else:
                    p += 1
            return Fraction(0), end
        return Fraction(0), self.skip_arg(pos)

    def var_lyrics(self, name, depth=0):
        toks = self.vars.get(name)
        if toks is None or depth > 8:
            return ""
        out = []
        for k, v in toks:
            if k == "lyr":
                out.append(self.expand_lyrics(v, depth + 1))
        return " ".join(out)

    def expand_lyrics(self, raw, depth=0):
        raw = re.sub(r"\\([A-Za-z]+)",
                     lambda m: (" " + self.var_lyrics(m.group(1), depth) + " ") if m.group(1) in self.vars else " ", raw)
        return raw

    def parse_lyricsto(self, pos):
        who = self.tk(pos + 1)
        p = pos + 2
        raw = None
        t = self.tk(p)
        if t[0] == "lyr":
            raw, p = t[1], p + 1
        elif t[0] == "cmd" and t[1] in self.vars:
            raw, p = self.var_lyrics(t[1]), p + 1
        elif t[0] == "op" and t[1] == "{":
            end = self.skip_balanced(p)
            parts = []
            for q in range(p + 1, end - 1):
                tt = self.tk(q)
                if tt[0] == "lyr":
                    parts.append(tt[1])
                elif tt[0] == "cmd" and tt[1] in self.vars:
                    parts.append(self.var_lyrics(tt[1]))
            raw, p = " ".join(parts), end
        else:
            p = self.skip_arg(p)
        if raw is not None and not self.mute and who[0] in ("str", "word"):
            self.lyr_assign.append((str(who[1]), self.expand_lyrics(raw), "name"))
        return Fraction(0), p

    def parse_repeat(self, pos, t0):
        kind = self.tk(pos + 1)
        count = self.tk(pos + 2)
        if count[0] != "num":
            self.warning("could not read \\repeat count")
            return Fraction(0), pos + 1
        N = count[1]
        body = pos + 3
        if kind[1] not in ("volta", "unfold"):
            self.warning("\\repeat %s treated as plain music" % kind[1])
            l, p = self.parse_item(body, t0)
            return l, self.skip_alternatives(p)
        # find extent of body by a muted dry run
        self.mute += 1
        saved_dur = self.dur
        _, body_end = self.parse_item(body, t0)
        self.mute -= 1
        self.dur = saved_dur
        alts = []
        p = body_end
        if self.tk(p)[0] == "cmd" and self.tk(p)[1] == "alternative" and self.is_op(p + 1, "{"):
            q = p + 2
            end = self.skip_balanced(p + 1)
            while q < end - 1:
                a_start = q
                self.mute += 1
                _, q2 = self.parse_item(q, t0)
                self.mute -= 1
                if q2 <= q:
                    q2 = q + 1
                alts.append((a_start, q2))
                q = q2
            p = end
        t = t0
        A = len(alts)
        for k in range(N):
            self.rel_saved = self.rel
            l, _ = self.parse_item(body, t)
            t += l
            if A:
                a0, a1 = alts[max(0, min(A - 1, k - (N - A)))]
                l2, _ = self.parse_item(a0, t)
                t += l2
        return t - t0, p

    def skip_alternatives(self, p):
        if self.tk(p)[0] == "cmd" and self.tk(p)[1] == "alternative" and self.is_op(p + 1, "{"):
            return self.skip_balanced(p + 1)
        return p

    def use_var(self, name, pos, t0):
        toks = self.vars[name]
        if len(toks) == 1 and toks[0][0] == "sch":
            if "ly:music?" in toks[0][1]:       # a one-music-argument function: pass the argument through
                return self.parse_item(pos + 1, t0)
            self.warning("scheme function \\%s ignored" % name)
            return Fraction(0), pos + 1
        if self.depth > 30:
            raise LyError("variables nested too deeply (\\%s)" % name)
        saved = self.toks
        self.toks = toks
        self.depth += 1
        try:
            l, _ = self.parse_seq_until(0, t0, ())
        finally:
            self.toks = saved
            self.depth -= 1
        return l, pos + 1

    # ---- top level
    def run(self):
        pos, n = 0, len(self.toks)
        book_depth = 0
        while pos < n:
            kind, val = self.toks[pos]
            if kind == "cmd":
                if val == "version":
                    pos += 2
                elif val == "language":
                    lg = self.tk(pos + 1)
                    if lg[0] in ("str", "word"):
                        self.lang = str(lg[1]).lower()
                    pos += 2
                elif val == "include":
                    f = self.tk(pos + 1)
                    pos += 2
                    if f[0] == "str":
                        base = f[1].lower().replace(".ly", "")
                        if base in ("deutsch", "english", "nederlands", "italiano", "catalan", "espanol", "français"):
                            self.lang = base
                        else:
                            self.warning("\\include %s not read" % f[1])
                elif val == "header":
                    pos = self.read_header(pos + 1)
                elif val in ("paper", "layout", "midi"):
                    pos = self.skip_arg(pos + 1)
                elif val in ("book", "bookpart"):
                    pos += 1
                    if self.is_op(pos, "{"):
                        pos += 1
                        book_depth += 1
                elif val == "score":
                    pos = self.parse_score(pos + 1)
                elif val in ("pointAndClickOff", "pointAndClickOn", "pointAndClickTypes", "maxima", "set", "override"):
                    pos += 1
                else:
                    pos = self.implicit_score(pos)
            elif kind == "sch":
                pos += 1
            elif kind == "word" and self.is_op(pos + 1, "="):
                pos = self.assignment(pos)
            elif kind == "op" and val == "}" and book_depth:
                book_depth -= 1
                pos += 1
            elif kind == "op" and val in ("{", "<<"):
                pos = self.implicit_score(pos)
            else:
                pos += 1

    def read_header(self, pos):
        if not self.is_op(pos, "{"):
            return pos
        end = self.skip_balanced(pos)
        for q in range(pos + 1, end - 2):
            if self.tk(q)[0] == "word" and self.is_op(q + 1, "=") and self.tk(q + 2)[0] == "str":
                if self.tk(q)[1] == "title" and not self.title:
                    self.title = self.tk(q + 2)[1]
                elif self.tk(q)[1] == "composer" and not self.composer:
                    self.composer = self.tk(q + 2)[1]
        return end

    def assignment(self, pos):
        name = self.toks[pos][1]
        start = pos + 2
        self.mute += 1
        saved_dur, saved_rel = self.dur, self.rel
        try:
            _, end = self.parse_item(start, Fraction(0))
        finally:
            self.mute -= 1
            self.dur, self.rel = saved_dur, saved_rel
        if end <= start:
            end = start + 1
        self.vars[name] = self.toks[start:end]
        return end

    def parse_score(self, pos):
        if not self.is_op(pos, "{"):
            return pos
        end = self.skip_balanced(pos)
        self.reset_score()
        p = pos + 1
        while p < end - 1:
            t = self.toks[p]
            if t[0] == "cmd" and t[1] in ("layout", "midi", "header"):
                p = self.skip_arg(p + 1)
            else:
                l, p2 = self.parse_item(p, Fraction(0))
                p = p2 if p2 > p else p + 1
        self.finish_score()
        return end

    def implicit_score(self, pos):
        self.reset_score()
        self.mute = 0
        l, p = self.parse_item(pos, Fraction(0))
        if self.events:
            self.finish_score()
        return p if p > pos else pos + 1

    def finish_score(self):
        self.scores.append({"events": self.events, "meta": self.meta, "ctxs": self.ctxs,
                            "lyr": self.lyr_assign, "end": self.max_end})


# --------------------------------------------------------------------------------------------
# lyrics assignment
# --------------------------------------------------------------------------------------------
LYR_TOK = re.compile(r'"[^"]*"|\S+')


def lyric_events(raw):
    """Return list of (text|None, syllabic) lyric events; None = skip/extender (consumes a note)."""
    raw = re.sub(r"\\set\s+\S+\s*=\s*(\"[^\"]*\"|\S+)", " ", raw)
    raw = re.sub(r"\\markup\s*\{[^}]*\}", " ", raw)
    raw = re.sub(r"\\[A-Za-z]+", " ", raw)
    toks = LYR_TOK.findall(raw)
    items = []   # (text, hyphen_after)
    i = 0
    while i < len(toks):
        t = toks[i]
        if t == "--":
            i += 1
            continue
        if t == "__":
            pass                    # extender line: attached to the previous syllable, consumes no note
        elif t == "_":
            items.append([None, False])
        elif t in ("~", "="):
            pass
        else:
            items.append([t.strip('"'), False])
        if i + 1 < len(toks) and toks[i + 1] == "--" and items:
            items[-1][1] = True
        i += 1
    out, prev_h = [], False
    for text, h in items:
        if text is None:
            out.append((None, None))
            prev_h = False
            continue
        syl = "middle" if (prev_h and h) else "begin" if h else "end" if prev_h else "single"
        out.append((text, syl))
        prev_h = h
    return out


def apply_lyrics(evs, raw, warn, label):
    """evs: events of one voice in time order. Sets ev['lyric'], ev['syl']."""
    notes = [e for e in evs if e["k"] == "n"]
    # melisma from slurs, ties
    in_slur = False
    for e in notes:
        sl = e["sl"] or ""
        e["_mel"] = in_slur and not sl.startswith("s")
        if "s" in sl and "e" in sl and sl.index("s") < sl.index("e"):
            in_slur = False
        elif sl.startswith("s"):
            in_slur = True
        elif "e" in sl:
            in_slur = False
    onsets, seen = [], set()
    open_ties = {}
    for e in notes:
        m = midi_of(e["p"])
        if m in open_ties and abs(open_ties[m] - e["t"]) < 1e-9:
            e["_cont"] = True
        else:
            e["_cont"] = False
        if e["tie"]:
            open_ties[m] = e["t"] + e["d"]
        else:
            open_ties.pop(m, None)
    groups = []
    for e in notes:
        if e["_cont"] or e["_mel"]:
            continue
        if groups and abs(groups[-1][0]["t"] - e["t"]) < 1e-9:
            groups[-1].append(e)
        else:
            groups.append([e])
    lev = lyric_events(raw)
    k = 0
    for g in groups:
        if k >= len(lev):
            break
        text, syl = lev[k]
        k += 1
        if text is not None:
            for e in g:
                e["lyric"], e["syl"] = text, syl
    if k < len(lev):
        warn("lyrics for %s: %d lyric events left over after the last note" % (label, len(lev) - k))
    elif len(groups) > len(lev):
        warn("lyrics for %s: %d notes have no lyric event" % (label, len(groups) - len(lev)))


# --------------------------------------------------------------------------------------------
# public entry
# --------------------------------------------------------------------------------------------
def parse_lilypond(text):
    if "\\include" in text and "\\score" not in text:
        raise LyError("file only includes other files")
    toks = tokenize(text)
    P = Parser(toks)
    try:
        P.run()
    except RecursionError:
        raise LyError("music nested too deeply")
    if not P.scores:
        raise LyError("no \\score or music found")

    info = {"movement": P.title, "work": P.title, "fifths": None, "meter": None, "tempo": None}
    parts_out = []          # aligned by order across scores
    bar_starts = []
    offset = Fraction(0)    # whole notes
    meter_set = False

    for si, sc in enumerate(P.scores):
        ctxs, events = sc["ctxs"], sc["events"]
        by_id = {c["id"]: c for c in ctxs}

        def staff_of(c):
            x = c
            while x is not None:
                if x["kind"] == "Staff":
                    return x
                x = x["parent"]
            return c

        groups, order = {}, []
        for e in events:
            s = staff_of(by_id[e["ctx"]])
            if s["id"] not in groups:
                groups[s["id"]] = []
                order.append(s["id"])
            groups[s["id"]].append(e)

        # lyrics
        for target, raw, how in sc["lyr"]:
            evs = None
            label = str(target)
            if how == "ctx":
                evs = [e for e in events if e["ctx"] == target]
                label = by_id[target]["name"] or by_id[target]["inst"] or "voice %s" % target
            else:
                cands = [c for c in ctxs if c["name"] == target]
                if cands:
                    c = cands[0]
                    ids = {x["id"] for x in ctxs if x is c or staff_of(x) is c}
                    evs = [e for e in events if e["ctx"] in ids]
                    ncs = {e["ctx"] for e in evs if e["k"] == "n"}
                    if len(ncs) > 1:
                        first = min(ncs)
                        evs = [e for e in evs if e["ctx"] == first]
            if not evs:
                P.warning("lyrics for \"%s\" found no voice" % label)
                continue
            evs.sort(key=lambda e: (e["t"], e["n"]))
            if any(e.get("lyric") for e in evs):
                continue            # second verse etc.: keep verse 1 only
            apply_lyrics(evs, raw, P.warning, label)

        # meta
        seen_m, metas = set(), []
        for m in sc["meta"]:
            if (m[0], m[1], str(m[2])) not in seen_m:
                seen_m.add((m[0], m[1], str(m[2])))
                metas.append(m)
        metas.sort(key=lambda m: m[0])      # stable: emission order kept within one time
        barlens = [(t, v) for t, k, v in metas if k == "barlen"]
        partial = next((v for t, k, v in metas if k == "partial" and t == 0), None)
        if info["fifths"] is None:
            f = next((v for t, k, v in metas if k == "fifths"), None)
            if f is not None:
                info["fifths"] = f
        if info["tempo"] is None:
            tp = next((v for t, k, v in metas if k == "tempo"), None)
            if tp is not None:
                info["tempo"] = round(tp, 1)
        if not meter_set and barlens:
            eff = [b for bt, b in barlens if bt == 0] or [barlens[0][1]]
            info["meter"] = {"beats": eff[-1][0], "beatType": eff[-1][1]}
            meter_set = True

        def barlen_at(t):
            cur = Fraction(1)
            for bt, (a, b) in barlens:
                if bt <= t:
                    cur = Fraction(a, b)
            return cur

        t, end = Fraction(0), sc["end"]
        first = True
        guard = 0
        while t < end and guard < 5000:
            bar_starts.append((offset + t) * 4)
            step = partial if (first and partial) else barlen_at(t)
            t += step
            first = False
            guard += 1

        # raw parts for this score
        for gi, sid in enumerate(order):
            staff = by_id[sid]
            notes = []
            for e in sorted(groups[sid], key=lambda e: (e["t"], e["n"])):
                notes.append({"voice": str(e["ctx"]), "staff": 1, "start": (offset + e["t"]) * 4,
                              "dur": e["d"] * 4,
                              "midi": midi_of(e["p"]) if e["k"] == "n" else None,
                              "lyric": e.get("lyric"), "syl": e.get("syl"),
                              "_tie": e["tie"] and e["k"] == "n"})
            if gi >= len(parts_out):
                parts_out.append({"id": "P%d" % (gi + 1), "name": None, "notes": [], "clefs": {}, "ids": []})
            po = parts_out[gi]
            if po["name"] is None:
                po["name"] = staff["inst"] or (staff["name"] if staff["name"] and not staff["implicit"] else None)
            if 1 not in po["clefs"] or po["clefs"][1] is None:
                po["clefs"][1] = staff["clef"]
            # make voice ids stable across scores of the same part: prefix by part
            for n in notes:
                n["voice"] = "%s:%s" % (po["id"], n["voice"] if staff["kind"] == "Staff" and False else n["voice"])
            po["notes"].extend(notes)
        if len(order) != len(parts_out):
            P.warning("score %d has %d staves, earlier score had %d" % (si + 1, len(order), len(parts_out)))
        offset += end

    # merge ties (build_tracks expects tied notes already merged)
    for po in parts_out:
        merged, open_ = [], {}
        for n in sorted(po["notes"], key=lambda x: (x["voice"], x["start"])):
            if n["midi"] is None:
                merged.append(n)
                continue
            key = (n["voice"], n["midi"])
            prev = open_.get(key)
            if prev is not None and prev["start"] + prev["dur"] == n["start"]:
                prev["dur"] += n["dur"]
                if not n["_tie"]:
                    del open_[key]
                continue
            merged.append(n)
            if n["_tie"]:
                open_[key] = n
            else:
                open_.pop(key, None)
        for n in merged:
            n.pop("_tie", None)
        po["notes"] = merged
        # voice ids collapse to the plain voice ids used by build_tracks
        vs = sorted({n["voice"] for n in po["notes"] if n["midi"] is not None})
        remap = {v: str(i + 1) for i, v in enumerate(vs)}
        for n in po["notes"]:
            n["voice"] = remap.get(n["voice"], "1")
        po["bar_starts"] = bar_starts
        nm = po["name"]
        if nm:
            key = nm.strip().lower()
            po["name"] = RENAISSANCE.get(key, nm)
        else:
            po["name"] = "Voice %s" % po["id"][1:]

    if not parts_out or not any(n["midi"] is not None for p in parts_out for n in p["notes"]):
        raise LyError("no notes found")
    info["bars"] = len(bar_starts)
    info["bar_starts"] = bar_starts
    if info["meter"] is None:
        info["meter"] = {"beats": 4, "beatType": 4}
    info["warnings"] = P.warn
    return info, parts_out
