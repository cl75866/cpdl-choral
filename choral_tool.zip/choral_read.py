#!/usr/bin/env python3
"""
choral_read.py - reads choral scores (MusicXML, plain or zipped) into Tutti note models.

Standard library only.  Used by choral_build.py; also usable on its own:
    python choral_read.py score.mxl            (prints a short report and writes score.model.json)

What it understands that a plain note dump does not:
  * repeats, first/second endings, D.C., D.S., Fine, coda  -> "playOrder" (bars in the order they are sung)
  * the printed bar numbers (pick-up bars, bars numbered from 0, 1a/1b ...)  -> "barLabels"
  * real bar positions for pick-ups and changes of metre -> "barStarts", "meters", "keys", "tempos"
  * voices by name (Soprano / Cantus / Superius / Tenor 2 / Bassus ...) or, failing that, by pitch -> part "voice"
  * SATB written on two staves (voices 1+2 / 3+4) and divisi written as chords
  * every verse of the words, not only the first -> note "v"
  * words written once for a homophonic piece are shared with the lines that move together with them
  * score-timewise files, UTF-16 files, files with stray bytes before <?xml
  * tempo from the metronome mark, or from the word (Andante ...), else a labelled guess
  * a list of things that look wrong ("warnings") so a person can check them
"""
import re
import sys
import json
import zipfile
import xml.etree.ElementTree as ET
from fractions import Fraction
from pathlib import Path

STEP = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
ACCOMP_RE = re.compile(r"piano|organ|keyboard|accomp|continuo|harpsichord|harp\b|guitar|lute|reduction|"
                       r"orchestra|violin|viola|cello|bass line|figured|\bbc\b|realisation|realization", re.I)
TEMPO_WORDS = {"grave": 46, "largo": 50, "lento": 54, "adagio": 60, "larghetto": 63, "andante": 76,
               "andantino": 84, "moderato": 100, "allegretto": 112, "allegro": 132, "vivace": 152,
               "presto": 176, "maestoso": 66, "sostenuto": 66, "tranquillo": 72, "con moto": 96}
TEMPO_RE = re.compile(r"\b(" + "|".join(sorted(TEMPO_WORDS, key=len, reverse=True)) + r")\b", re.I)
ROLE_RES = [  # first match wins; order matters ("contratenor bassus" is a bass, "contralto" an alto)
    ("B", re.compile(r"\b(bass|basses|bassus|basso|basse|bajo|baixo|baritone|baritono|bariton|bassi)\b|^b\d?$|^bs\b", re.I)),
    ("T", re.compile(r"\b(tenor|tenore|tenors|ténor|tenori|quintus tenor)\b|^t\d?$", re.I)),
    ("A", re.compile(r"\b(alto|altus|contralto|alti|countertenor|counter-tenor|contratenor altus|alt|contr?a)\b|^a\d?$", re.I)),
    ("S", re.compile(r"\b(soprano|sopran|sopranos|superius|cantus|discantus|discant|descant|treble|canto|dessus|tiple|"
                     r"soprani|sop|boy|boys)\b|^s\d?$|^sop\b", re.I)),
]
VOICE_RANGE = {"S": (57, 84), "A": (53, 77), "T": (45, 69), "B": (38, 62)}   # comfortable limits, a little generous
VOICE_NAME = {"S": "Soprano", "A": "Alto", "T": "Tenor", "B": "Bass"}


def local(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def child(el, name):
    if el is None:
        return None
    for c in el:
        if local(c.tag) == name:
            return c
    return None


def children(el, name):
    return [c for c in el if local(c.tag) == name] if el is not None else []


def text_of(el, name, default=None):
    c = child(el, name)
    return (c.text or "").strip() if c is not None and c.text is not None else default


def f4(x):
    return round(float(x), 4)


# ----------------------------------------------------------------------------------------
# reading the file
# ----------------------------------------------------------------------------------------
def read_bytes(path):
    p = str(path)
    with open(p, "rb") as fh:
        magic = fh.read(4)
    if magic[:2] == b"PK":
        with zipfile.ZipFile(p) as z:
            names = z.namelist()
            root_name = None
            if "META-INF/container.xml" in names:
                try:
                    c = ET.fromstring(z.read("META-INF/container.xml"))
                    for rf in c.iter():
                        if local(rf.tag) == "rootfile" and rf.get("full-path") and \
                                "pdf" not in (rf.get("media-type") or ""):
                            root_name = rf.get("full-path")
                            break
                except ET.ParseError:
                    pass
            if not root_name or root_name not in names:
                cands = [n for n in names if n.lower().endswith((".xml", ".musicxml")) and not n.startswith("META-INF")]
                if not cands:
                    raise ValueError("no MusicXML inside the .mxl file")
                root_name = sorted(cands, key=lambda n: -z.getinfo(n).file_size)[0]
            return z.read(root_name)
    return Path(p).read_bytes()


def to_root(data):
    """Bytes -> Element, forgiving about BOMs, junk before the prolog, and encodings."""
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        data = data.decode("utf-16").encode("utf-8")
        data = re.sub(rb"^(<\?xml[^>]*encoding=)[\"'][^\"']*[\"']", rb'\1"UTF-8"', data.lstrip(b"\xef\xbb\xbf"))
    else:
        data = data.lstrip(b"\xef\xbb\xbf")
    i = data.find(b"<?xml")
    j = data.find(b"<score-")
    if i > 0 and (j < 0 or i < j):
        data = data[i:]
    elif i < 0 and j > 0:
        data = data[j:]
    try:
        root = ET.fromstring(data)
    except ET.ParseError:
        # a few editors write named HTML entities or stray control characters
        txt = data.decode("utf-8", "replace")
        txt = re.sub(r"&(?!(amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)", "&amp;", txt)
        txt = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", txt)
        txt = re.sub(r"<!DOCTYPE[^>]*>", "", txt)
        root = ET.fromstring(txt.encode("utf-8"))
    if local(root.tag) == "score-timewise":
        root = timewise_to_partwise(root)
    if local(root.tag) != "score-partwise":
        raise ValueError("not a MusicXML score (%s)" % local(root.tag))
    return root


def timewise_to_partwise(root):
    new = ET.Element("score-partwise", root.attrib)
    for ch in root:
        if local(ch.tag) != "measure":
            new.append(ch)
    parts = {}
    for meas in children(root, "measure"):
        for p in children(meas, "part"):
            pid = p.get("id")
            if pid not in parts:
                parts[pid] = ET.SubElement(new, "part", {"id": pid})
            m = ET.SubElement(parts[pid], "measure", dict(meas.attrib))
            for el in p:
                m.append(el)
    return new


# ----------------------------------------------------------------------------------------
# MusicXML
# ----------------------------------------------------------------------------------------
def _nums(s):
    out = set()
    for tok in re.split(r"[,\s]+", s or ""):
        m = re.match(r"^(\d+)\s*-\s*(\d+)$", tok)
        if m:
            out.update(range(int(m.group(1)), int(m.group(2)) + 1))
        elif tok.isdigit():
            out.add(int(tok))
    return out or {1}


def _first_number(s):
    m = re.search(r"\d+(?:\.\d+)?", s or "")
    return float(m.group(0)) if m else None


UNIT_Q = {"breve": 8, "whole": 4, "half": 2, "quarter": 1, "eighth": .5, "16th": .25, "32nd": .125, "64th": .0625}


def parse_musicxml(data, warn=None):
    warn = warn if warn is not None else []
    root = to_root(data)
    names = {}
    pl = child(root, "part-list")
    if pl is not None:
        for sp in children(pl, "score-part"):
            nm = text_of(sp, "part-name") or text_of(sp, "part-abbreviation") or sp.get("id")
            names[sp.get("id")] = re.sub(r"\s+", " ", nm or "").strip()

    info = {"movement": text_of(root, "movement-title"), "work": None, "composer": None, "lyricist": None,
            "title": None, "number": text_of(root, "movement-number")}
    w = child(root, "work")
    if w is not None:
        info["work"] = text_of(w, "work-title")
        info["number"] = info["number"] or text_of(w, "work-number")
    ident = child(root, "identification")
    for cr in children(ident, "creator"):
        t = (cr.get("type") or "").lower()
        if t == "composer" and not info["composer"]:
            info["composer"] = (cr.text or "").strip() or None
        elif t in ("lyricist", "poet") and not info["lyricist"]:
            info["lyricist"] = (cr.text or "").strip() or None
    credits = []
    for cw in children(root, "credit"):
        ct = " ".join((x.text or "").strip() for x in children(cw, "credit-words") if x.text).strip()
        if ct:
            credits.append(ct)
    info["credits"] = credits[:6]

    raw_parts = []
    for pi, part in enumerate(children(root, "part")):
        pid = part.get("id") or "P%d" % (pi + 1)
        raw_parts.append(_parse_part(part, pid, names.get(pid, pid), warn))
    if not raw_parts:
        raise ValueError("no parts in the file")

    n_meas = max(len(p["measures"]) for p in raw_parts)
    # one set of bar positions for everybody: each bar is as long as the longest part makes it
    lens = []
    for k in range(n_meas):
        ls = [p["measures"][k]["len"] for p in raw_parts if k < len(p["measures"])]
        lens.append(max(ls) if ls else Fraction(0))
    bar_starts = [Fraction(0)]
    for L in lens:
        bar_starts.append(bar_starts[-1] + L)
    # the structure (repeats, numbers, key, metre, tempo) comes from the first part that has any, bar by bar
    struct = []
    for k in range(n_meas):
        s = {}
        for p in raw_parts:
            if k < len(p["measures"]):
                m = p["measures"][k]
                for key, val in m["s"].items():
                    empty = val is None or val is False or (isinstance(val, (set, list)) and not val)
                    if key not in s and not empty:
                        s[key] = val
        s.setdefault("num", str(k + 1))
        struct.append(s)

    parts_out = []
    for p in raw_parts:
        notes = []
        for k, m in enumerate(p["measures"]):
            base = bar_starts[k]
            for n in m["notes"]:
                n = dict(n)
                n["start"] = base + n.pop("off")
                notes.append(n)
        # ties that cross a barline were joined while reading; sort for tidiness
        notes.sort(key=lambda n: (n["start"], n["voice"]))
        parts_out.append({"id": p["id"], "name": p["name"], "notes": notes, "clefs": p["clefs"],
                          "bar_starts": bar_starts[:-1], "staves": p["staves"]})

    # metre / key / tempo lists
    meters, keys, tempos, words = [], [], [], []
    last_m = last_k = None
    for k, s in enumerate(struct):
        if s.get("meter") and s["meter"] != last_m:
            meters.append({"bar": k, "beats": s["meter"][0], "beatType": s["meter"][1]})
            last_m = s["meter"]
        if s.get("key") is not None and s["key"] != last_k:
            keys.append({"bar": k, "fifths": s["key"]})
            last_k = s["key"]
        for off, bpm in s.get("tempos", []):
            tempos.append({"bar": k, "beat": f4(off), "bpm": bpm})
        for wd in s.get("words", []):
            words.append((k, wd))
    if not meters:
        meters = [{"bar": 0, "beats": 4, "beatType": 4}]
    if not keys:
        keys = [{"bar": 0, "fifths": 0}]
    tempo_text = None
    for k, wd in words:
        mt = TEMPO_RE.search(wd)
        if mt:
            tempo_text = wd.strip()
            break
    # bars that look wrong in one part: the usual sign of a misread note or rhythm
    issues = []
    cur = meters[0]
    mi_ = 0
    for k in range(n_meas):
        while mi_ + 1 < len(meters) and meters[mi_ + 1]["bar"] <= k:
            mi_ += 1
        full = Fraction(meters[mi_]["beats"] * 4, meters[mi_]["beatType"])
        if k == 0 or k == n_meas - 1 or struct[k].get("implicit"):
            continue
        for p in raw_parts:
            if k < len(p["measures"]):
                L = p["measures"][k]["len"]
                if L != full:
                    issues.append({"bar": k, "part": p["name"], "found": f4(L), "expected": f4(full),
                                   "kind": "empty" if L == 0 else "length"})
    info["bar_issues"] = issues
    info.update({"bars": n_meas, "bar_starts": bar_starts[:-1], "bar_end": bar_starts[-1],
                 "meters": meters, "keys": keys, "tempos": tempos, "tempo_text": tempo_text,
                 "meter": {"beats": meters[0]["beats"], "beatType": meters[0]["beatType"]},
                 "fifths": keys[0]["fifths"], "struct": struct,
                 "bar_labels": [s["num"] for s in struct], "warnings": warn})
    info["tempo"] = tempos[0]["bpm"] if tempos else None
    jump_words = [wd for k, wd in words if re.search(r"\b(d\.?\s?c\.?|d\.?\s?s\.?|da capo|dal segno|fine|coda)\b", wd, re.I)]
    if jump_words and not any(s.get("dacapo") or s.get("dalsegno") or s.get("fine") or s.get("tocoda") for s in struct):
        warn.append("The score has the text '%s' but no playback instruction for it, so it is played straight through." % jump_words[0].strip()[:40])
    return info, parts_out


def _parse_part(part, pid, name, warn):
    div = Fraction(1)
    meter = (4, 4)
    trans_semis = 0
    clefs = {}
    open_ties = {}
    measures = []
    volta = None            # the set of ending numbers we are inside
    staves = 1
    for mi, meas in enumerate(children(part, "measure")):
        M = {"notes": [], "len": Fraction(0),
             "s": {"num": meas.get("number") or str(mi + 1), "implicit": meas.get("implicit") == "yes",
                   "tempos": [], "words": []}}
        S = M["s"]
        cursor = Fraction(0)
        maxcur = Fraction(0)
        last_start = Fraction(0)
        pending_end = False
        for el in meas:
            tag = local(el.tag)
            if tag == "attributes":
                d = text_of(el, "divisions")
                if d:
                    try:
                        div = Fraction(d)
                    except (ValueError, ZeroDivisionError):
                        pass
                st = text_of(el, "staves")
                if st and st.isdigit():
                    staves = max(staves, int(st))
                tr = child(el, "transpose")
                if tr is not None:
                    try:
                        trans_semis = int(text_of(tr, "chromatic", "0") or 0) + 12 * int(text_of(tr, "octave-change", "0") or 0)
                    except ValueError:
                        pass
                k = child(el, "key")
                if k is not None:
                    f = text_of(k, "fifths")
                    if f is not None:
                        try:
                            S["key"] = int(f)
                        except ValueError:
                            pass
                t = child(el, "time")
                if t is not None:
                    try:
                        bt = text_of(t, "beats", "4")
                        beats = sum(int(x) for x in re.findall(r"\d+", bt))
                        typ = int(text_of(t, "beat-type", "4").split("+")[0])
                        meter = (beats or 4, typ or 4)
                        S["meter"] = meter
                    except (ValueError, AttributeError):
                        pass
                for c in children(el, "clef"):
                    num = int(c.get("number") or 1)
                    sign = text_of(c, "sign")
                    oc = text_of(c, "clef-octave-change")
                    line = text_of(c, "line")
                    if sign == "G":
                        v = "treble8" if oc == "-1" else "treble"
                    elif sign == "F":
                        v = "bass"
                    elif sign == "C":
                        v = "alto" if line == "3" else "tenor" if line == "4" else "alto"
                    else:
                        v = None
                    clefs.setdefault(num, v)
            elif tag == "direction":
                snd = child(el, "sound")
                if snd is not None:
                    if snd.get("tempo"):
                        try:
                            S["tempos"].append((cursor / 1, round(float(snd.get("tempo")), 1)))
                        except ValueError:
                            pass
                    for a in ("segno", "coda"):
                        if snd.get(a):
                            S[a] = snd.get(a)
                    if snd.get("dacapo") == "yes":
                        S["dacapo"] = True
                    if snd.get("dalsegno"):
                        S["dalsegno"] = snd.get("dalsegno")
                    if snd.get("tocoda"):
                        S["tocoda"] = snd.get("tocoda")
                    if snd.get("fine"):
                        S["fine"] = True
                for dt in children(el, "direction-type"):
                    for wd in children(dt, "words"):
                        if wd.text and wd.text.strip():
                            S["words"].append(wd.text.strip())
                    if child(dt, "segno") is not None and not S.get("segno"):
                        S["segno"] = "segno"
                    if child(dt, "coda") is not None and not S.get("coda"):
                        S["coda"] = "coda"
                    mt = child(dt, "metronome")
                    if mt is not None and not any(True for _ in (snd.get("tempo") if snd is not None else [])):
                        bu = text_of(mt, "beat-unit")
                        pm = _first_number(text_of(mt, "per-minute"))
                        if pm and bu in UNIT_Q:
                            q = UNIT_Q[bu] * (1.5 if child(mt, "beat-unit-dot") is not None else 1)
                            S["tempos"].append((cursor / 1, round(pm * q, 1)))
            elif tag == "sound":
                if el.get("tempo"):
                    try:
                        S["tempos"].append((cursor / 1, round(float(el.get("tempo")), 1)))
                    except ValueError:
                        pass
                for a in ("segno", "coda"):
                    if el.get(a):
                        S[a] = el.get(a)
                if el.get("dacapo") == "yes":
                    S["dacapo"] = True
                if el.get("dalsegno"):
                    S["dalsegno"] = el.get("dalsegno")
                if el.get("tocoda"):
                    S["tocoda"] = el.get("tocoda")
                if el.get("fine"):
                    S["fine"] = True
            elif tag == "barline":
                rep = child(el, "repeat")
                loc = el.get("location") or "right"
                if rep is not None:
                    if rep.get("direction") == "forward":
                        S["fwd"] = True
                    elif rep.get("direction") == "backward":
                        try:
                            S["back"] = int(rep.get("times") or 2)
                        except ValueError:
                            S["back"] = 2
                en = child(el, "ending")
                if en is not None:
                    typ = en.get("type")
                    if typ == "start":
                        volta = _nums(en.get("number"))
                        S["volta_start"] = True
                    elif typ in ("stop", "discontinue"):
                        pending_end = True
                        if volta is None:
                            volta = _nums(en.get("number"))
                        S["volta_stop"] = typ
                if loc == "right" and child(el, "bar-style") is not None and text_of(el, "bar-style") in ("light-heavy",) and rep is None:
                    S["final"] = True
            elif tag == "backup":
                cursor -= Fraction(text_of(el, "duration", "0")) / div
            elif tag == "forward":
                cursor += Fraction(text_of(el, "duration", "0")) / div
            elif tag == "note":
                if child(el, "grace") is not None or child(el, "cue") is not None:
                    continue
                is_chord = child(el, "chord") is not None
                is_rest = child(el, "rest") is not None
                dtxt = text_of(el, "duration")
                if dtxt is None:
                    if is_rest:
                        dur = Fraction(meter[0] * 4, meter[1])
                    else:
                        continue
                else:
                    dur = Fraction(dtxt) / div
                if is_rest and child(el, "rest").get("measure") == "yes":
                    dur = max(dur, Fraction(meter[0] * 4, meter[1])) if dtxt is None else dur
                start = last_start if is_chord else cursor
                voice = text_of(el, "voice", "1")
                staff = int(text_of(el, "staff", "1") or 1)
                midi = None
                if not is_rest:
                    p = child(el, "pitch")
                    if p is None:
                        if not is_chord:
                            cursor += dur
                            maxcur = max(maxcur, cursor)
                        continue                    # unpitched percussion etc.
                    octv = int(text_of(p, "octave", "4"))
                    alter = float(text_of(p, "alter", "0") or 0)
                    midi = 12 * (octv + 1) + STEP.get(text_of(p, "step", "C"), 0) + int(round(alter)) + trans_semis
                tie_els = children(el, "tie")
                for nt in children(el, "notations"):
                    tie_els = tie_els + children(nt, "tied")
                tie_stop = any(t.get("type") == "stop" for t in tie_els)
                tie_start = any(t.get("type") == "start" for t in tie_els)
                verses = {}
                for ly in children(el, "lyric"):
                    key = ly.get("number") or ly.get("name") or "1"
                    pieces = [(c.text or "").strip() for c in ly if local(c.tag) == "text" and (c.text or "").strip()]
                    if not pieces:
                        continue
                    txt = "‿".join(pieces) if child(ly, "elision") is not None else " ".join(pieces)
                    verses.setdefault(key, (txt, text_of(ly, "syllabic", "single")))
                if is_chord and M["notes"] and not is_rest:
                    # a chord: the extra pitches belong to the note just read (divisi written as a chord)
                    for prev in reversed(M["notes"]):
                        if prev["voice"] == voice and prev["off"] == start and prev["midi"] is not None:
                            prev.setdefault("extra", []).append(midi)
                            break
                    last_start = start
                    continue
                if midi is not None and tie_stop and (voice, staff, midi) in open_ties:
                    prev = open_ties[(voice, staff, midi)]
                    prev["dur"] += dur
                    if not tie_start:
                        del open_ties[(voice, staff, midi)]
                else:
                    nn = {"voice": voice, "staff": staff, "off": start, "dur": dur, "midi": midi,
                          "verses": verses}
                    M["notes"].append(nn)
                    if midi is not None and tie_start:
                        open_ties[(voice, staff, midi)] = nn
                last_start = cursor if not is_chord else last_start
                if not is_chord:
                    last_start = cursor
                    cursor += dur
            maxcur = max(maxcur, cursor)
        if volta is not None:
            S["volta"] = set(volta)
        if pending_end:
            volta = None
        M["len"] = maxcur
        measures.append(M)
    if trans_semis <= -12 and any(v == "treble" for v in clefs.values()):
        clefs = {k: ("treble8" if v == "treble" else v) for k, v in clefs.items()}
    return {"id": pid, "name": name, "measures": measures, "clefs": clefs, "staves": staves}


# ----------------------------------------------------------------------------------------
# repeats -> the order the bars are sung
# ----------------------------------------------------------------------------------------
def play_order(struct, warn):
    n = len(struct)
    order = []
    segno = {}
    coda = {}
    for k, s in enumerate(struct):
        if s.get("segno"):
            segno.setdefault(s["segno"], k)
        if s.get("coda"):
            coda.setdefault(s["coda"], k)
    i = 0
    rep_start = 0
    done = {}
    pass_no = 1
    jumped = False
    ignore_repeats = False
    safe = 0
    while i < n and safe < n * 12 + 50:
        safe += 1
        s = struct[i]
        if s.get("fwd") and not (done.get(("f", i)) == "open"):
            rep_start = i
            pass_no = 1
            done[("f", i)] = "open"
        vol = s.get("volta")
        if vol and not ignore_repeats and pass_no not in vol:
            i += 1                       # not our ending this time round
            continue
        order.append(i)
        if jumped and s.get("fine"):
            break
        if jumped and s.get("tocoda") and s["tocoda"] in coda and coda[s["tocoda"]] != i:
            i = coda[s["tocoda"]]
            ignore_repeats = True
            continue
        if s.get("back") and not ignore_repeats:
            times = s["back"]
            c = done.get(("b", i), 0)
            if c < times - 1:
                done[("b", i)] = c + 1
                pass_no = c + 2
                i = rep_start
                continue
            done[("b", i)] = 0
            pass_no = 1
            rep_start = i + 1
        if (s.get("dacapo") or s.get("dalsegno")) and not jumped:
            if s.get("dacapo"):
                tgt = 0
            else:
                tgt = segno.get(s["dalsegno"])
            if tgt is None:
                warn.append("D.S. refers to a segno sign that is not in the score.")
            else:
                jumped = True
                ignore_repeats = True
                pass_no = 1
                i = tgt
                continue
        i += 1
    if safe >= n * 12 + 50:
        warn.append("The repeat marks could not be followed to an end, so the piece is played straight through.")
        return list(range(n))
    return order


# ----------------------------------------------------------------------------------------
# voices, divisi, words
# ----------------------------------------------------------------------------------------
def role_of(name):
    nm = (name or "").strip()
    low = re.sub(r"[\.\(\)\[\]]", " ", nm.lower()).strip()
    if not low:
        return None
    for letter, rx in ROLE_RES:
        if rx.search(low):
            return letter
    return None


def _section_no(name):
    m = re.search(r"(?:\s|^)(\d|i{1,3}|iv)\b\.?\s*$", (name or "").strip().lower())
    return m.group(1) if m else None


def _mean(ns):
    ps = [n["midi"] for n in ns if n["midi"] is not None]
    return sum(ps) / len(ps) if ps else 0


def build_tracks(parts, bar_starts, warn):
    """Raw parts -> model tracks: one per sung line, named, with a voice letter."""
    raw = []          # (name, clef, notes, accomp, source part id)
    for p in parts:
        accomp = bool(ACCOMP_RE.search(p["name"] or ""))
        sounding = [n for n in p["notes"] if n["midi"] is not None]
        if not sounding:
            continue
        vkeys = sorted({(n["staff"], n["voice"]) for n in sounding})
        # how much of the time is each voice actually sounding?
        def span(vk):
            return sum(float(n["dur"]) for n in sounding if (n["staff"], n["voice"]) == vk)
        total_span = max(span(vk) for vk in vkeys)
        real = [vk for vk in vkeys if span(vk) >= 0.25 * total_span]
        minor = [vk for vk in vkeys if vk not in real]
        groups = []
        if accomp or len(real) <= 1:
            groups.append(("", sounding if not accomp else p["notes"], p["clefs"].get(vkeys[0][0], p["clefs"].get(1))))
            if len(vkeys) > 1 and not accomp:
                pass
        else:
            ordered = sorted(real, key=lambda vk: -_mean([n for n in sounding if (n["staff"], n["voice"]) == vk]))
            for vk in ordered:
                ns = [n for n in p["notes"] if (n["staff"], n["voice"]) == vk or n["midi"] is None and False]
                groups.append((vk, ns, p["clefs"].get(vk[0], p["clefs"].get(1))))
        # sparse extra voices are divisi in a line that already exists: fold into the nearest real voice
        for gi, (vk, ns, clef) in enumerate(groups):
            if minor and vk != "" and gi == 0:
                pass
        for vk, ns, clef in groups:
            raw.append({"name": p["name"], "clef": clef, "notes": [dict(n) for n in ns], "accomp": accomp,
                        "pid": p["id"], "split": len(groups) > 1, "bar_starts": bar_starts, "minor": minor,
                        "all": p["notes"]})
    # chords written as divisi in a vocal line
    tracks = []
    for r in raw:
        ns = r["notes"]
        if not r["accomp"]:
            ns = _sort(ns)
            chord_onsets = [n for n in ns if n.get("extra")]
            snd = [n for n in ns if n["midi"] is not None]
            frac = len(chord_onsets) / max(1, len(snd))
            if chord_onsets and frac >= 0.2:
                hi, lo = [], []
                for n in ns:
                    if n["midi"] is None:
                        hi.append(n)
                        lo.append(dict(n))
                        continue
                    pitches = sorted([n["midi"]] + n.get("extra", []), reverse=True)
                    a = dict(n); a["midi"] = pitches[0]; a.pop("extra", None)
                    b = dict(n); b["midi"] = pitches[-1]; b.pop("extra", None)
                    hi.append(a)
                    lo.append(b)
                for sub, lst in (("", hi), ("", lo)):
                    t = dict(r); t["notes"] = lst; t["divisi"] = True
                    tracks.append(t)
                warn.append("%s has chords in %d%% of its notes; it is shown as two lines." % (r["name"], round(frac * 100)))
                continue
            if chord_onsets:
                bars = sorted({_bar(bar_starts, n["start"]) + 1 for n in chord_onsets})
                warn.append("%s has divisi chords in bar%s %s; the top note is sung." % (
                    r["name"], "s" if len(bars) > 1 else "", ", ".join(map(str, bars[:6])) + ("..." if len(bars) > 6 else "")))
        t = dict(r); t["notes"] = ns
        tracks.append(t)

    # names and voice letters
    named = []
    for t in tracks:
        lab = role_of(t["name"])
        t["role"] = "accompaniment" if t["accomp"] else "voice"
        t["letter"] = lab
        t["mean"] = _mean(t["notes"])
        named.append(t)
    voices = [t for t in named if t["role"] == "voice"]
    # the pieces of one written part (e.g. 'Soprano' with two voices) become Soprano 1 / Soprano 2
    by_pid = {}
    for t in voices:
        by_pid.setdefault(t["pid"], []).append(t)
    for pid, ts in by_pid.items():
        if len(ts) > 1:
            base_letter = ts[0]["letter"]
            if base_letter:
                for i, t in enumerate(sorted(ts, key=lambda x: -x["mean"])):
                    t["name"] = "%s %d" % (VOICE_NAME[base_letter], i + 1)
                    t["letter"] = base_letter
            else:
                # one staff pair holding the whole choir: sort by pitch, name them
                ordered = sorted(ts, key=lambda x: -x["mean"])
                letters = _letters_for(len(ordered))
                counts = {}
                for t, L in zip(ordered, letters):
                    counts[L] = counts.get(L, 0) + 1
                seen = {}
                for t, L in zip(ordered, letters):
                    seen[L] = seen.get(L, 0) + 1
                    t["letter"] = L
                    t["name"] = VOICE_NAME[L] if counts[L] == 1 else "%s %d" % (VOICE_NAME[L], seen[L])
    # unnamed lines: by pitch
    unnamed = [t for t in voices if not t["letter"]]
    if unnamed:
        used = {t["letter"] for t in voices if t["letter"]}
        ordered = sorted(unnamed, key=lambda x: -x["mean"])
        if len(unnamed) == len(voices):
            letters = _letters_for(len(ordered))
        else:
            free = [L for L in "SATB" if L not in used] or list("SATB")
            letters = [free[min(len(free) - 1, int(i * len(free) / len(ordered)))] for i in range(len(ordered))]
        for t, L in zip(ordered, letters):
            t["letter"] = L
            if not t["name"] or re.match(r"^(voice|vox|part|choir|chor|singer|staff|p\d+|v\d+|track|\d+)\b", t["name"].strip(), re.I) or t["name"] in ("", None):
                t["name"] = VOICE_NAME[L]
    # one more pass: duplicate names get numbers
    nm_count = {}
    for t in voices:
        nm_count[t["name"]] = nm_count.get(t["name"], 0) + 1
    seen = {}
    for t in sorted(voices, key=lambda x: -x["mean"]):
        if nm_count[t["name"]] > 1:
            seen[t["name"]] = seen.get(t["name"], 0) + 1
            t["name"] = "%s %d" % (t["name"], seen[t["name"]])
    # final order: S A T B (by letter then pitch), accompaniment last
    order = {"S": 0, "A": 1, "T": 2, "B": 3, None: 4}
    voices.sort(key=lambda t: (order.get(t["letter"], 4), -t["mean"]))
    acc = [t for t in named if t["role"] != "voice"]
    out = []
    ids = {}
    for t in voices + acc:
        base = t["pid"]
        ids[base] = ids.get(base, 0) + 1
        tid = base if ids[base] == 1 and sum(1 for x in voices + acc if x["pid"] == base) == 1 else "%s-%d" % (base, ids[base])
        notes = _clean_notes(t["notes"], bar_starts, t["role"] == "voice")
        if not any("midi" in n for n in notes):
            continue
        d = {"id": tid, "name": t["name"], "role": t["role"], "notes": notes}
        if t["role"] == "voice" and t["letter"]:
            d["voice"] = t["letter"]
        if t["clef"]:
            d["clef"] = t["clef"]
        ps = [n["midi"] for n in notes if "midi" in n]
        d["range"] = [min(ps), max(ps)]
        out.append(d)
    return out


def _letters_for(k):
    if k <= 1:
        return ["S"]
    if k == 2:
        return ["S", "B"]
    if k == 3:
        return ["S", "A", "B"]
    return ["SATB"[min(3, int(i * 4 / k))] for i in range(k)]


def _sort(ns):
    return sorted(ns, key=lambda n: (n["start"], -(n["midi"] if n["midi"] is not None else -1)))


def _bar(starts, t):
    lo, hi = 0, len(starts) - 1
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if starts[mid] <= t + Fraction(1, 1000000):
            lo = mid
        else:
            hi = mid - 1
    return lo


def _clean_notes(ns, bar_starts, vocal):
    ns = _sort(ns)
    out = []
    seen = {}
    for n in ns:
        if n["midi"] is not None and vocal:
            prev = seen.get(n["start"])
            if prev is not None:                       # two notes at once in a single sung line: keep the higher
                if n["midi"] > prev["midi"]:
                    prev["midi"] = n["midi"]
                continue
        nd = {"start": f4(n["start"]), "duration": f4(n["dur"])}
        if n["midi"] is None:
            nd["rest"] = True
        else:
            nd["midi"] = n["midi"]
            vs = n.get("verses") or {}
            keys = sorted(vs, key=lambda k: (0, int(k)) if str(k).isdigit() else (1, 0))
            if keys:
                t, syl = vs[keys[0]]
                nd["lyric"] = t
                if syl in ("single", "begin", "middle", "end"):
                    nd["syllabic"] = syl
                more = {}
                for k in keys[1:]:
                    t2, s2 = vs[k]
                    more[str(k)] = t2 + ("-" if s2 in ("begin", "middle") else "")
                if more:
                    nd["v"] = more
        out.append(nd)
        if n["midi"] is not None and vocal:
            seen[n["start"]] = nd
    # merge neighbouring rests
    merged = []
    for n in out:
        if merged and n.get("rest") and merged[-1].get("rest") and abs(merged[-1]["start"] + merged[-1]["duration"] - n["start"]) < 1e-3:
            merged[-1]["duration"] = f4(merged[-1]["duration"] + n["duration"])
        else:
            merged.append(n)
    return merged


def share_words(tracks, warn):
    """Words written under one line only (common in hymn-style editions) are given to lines that move with it."""
    vocal = [t for t in tracks if t["role"] == "voice"]
    def cover(t):
        snd = [n for n in t["notes"] if "midi" in n]
        return sum(1 for n in snd if n.get("lyric")) / max(1, len(snd))
    donors = [t for t in vocal if cover(t) >= 0.6]
    if not donors:
        return
    for t in vocal:
        if cover(t) >= 0.3:
            continue
        snd = [n for n in t["notes"] if "midi" in n]
        if not snd:
            continue
        best, best_hit = None, 0
        for d in donors:
            starts = {round(n["start"], 3): n for n in d["notes"] if "midi" in n and n.get("lyric")}
            hit = sum(1 for n in snd if round(n["start"], 3) in starts)
            if hit > best_hit:
                best, best_hit = (d, starts), hit
        if best and best_hit / len(snd) >= 0.6:
            d, starts = best
            for n in snd:
                src = starts.get(round(n["start"], 3))
                if src:
                    n["lyric"] = src["lyric"]
                    if "syllabic" in src:
                        n["syllabic"] = src["syllabic"]
                    if "v" in src:
                        n["v"] = dict(src["v"])
            warn.append("%s had no words of its own; the words from %s are shown (the lines move together)." % (t["name"], d["name"]))


# ----------------------------------------------------------------------------------------
# checks
# ----------------------------------------------------------------------------------------
def check(info, tracks, warn):
    starts = [float(b) for b in info["bar_starts"]]
    meters = info["meters"]
    # full bars the right length?  (the first and last bar may be short: pick-up, final bar)
    def meter_at(k):
        m = meters[0]
        for x in meters:
            if x["bar"] <= k:
                m = x
        return m["beats"] * 4.0 / m["beatType"]
    ends = starts[1:] + [float(info["bar_end"])]
    odd = []
    for k in range(1, max(1, len(starts) - 1)):
        L = ends[k] - starts[k]
        if abs(L - meter_at(k)) > 0.01 and not (k < len(info["struct"]) and info["struct"][k].get("implicit")):
            odd.append(k + 1)
    if odd:
        warn.append("Bar%s %s %s not the length of the time signature (the printed bar numbers may drift)." % (
            "s" if len(odd) > 1 else "", ", ".join(map(str, odd[:6])) + ("..." if len(odd) > 6 else ""),
            "are" if len(odd) > 1 else "is"))
    for t in tracks:
        if t["role"] != "voice" or "voice" not in t:
            continue
        lo, hi = VOICE_RANGE[t["voice"]]
        out_lo = [n for n in t["notes"] if "midi" in n and n["midi"] < lo - 5]
        out_hi = [n for n in t["notes"] if "midi" in n and n["midi"] > hi + 5]
        if out_lo or out_hi:
            warn.append("%s goes outside the usual range of a %s (%d notes); the part name or clef may not match the music." % (
                t["name"], VOICE_NAME[t["voice"]].lower(), len(out_lo) + len(out_hi)))
        snd = [n for n in t["notes"] if "midi" in n]
        over = 0
        for a, b in zip(snd, snd[1:]):
            if a["start"] + a["duration"] > b["start"] + 0.01:
                over += 1
        if over:
            warn.append("%s has %d overlapping notes (two voices in one line)." % (t["name"], over))
    lyr_tracks = [t for t in tracks if t["role"] == "voice" and any(n.get("lyric") for n in t["notes"])]
    if not lyr_tracks:
        warn.append("The file has no words, so the player shows notes only.")
    else:
        for t in tracks:
            if t["role"] != "voice":
                continue
            snd = [n for n in t["notes"] if "midi" in n]
            miss = [n for n in snd if not n.get("lyric")]
            if lyr_tracks and snd and len(miss) / len(snd) > 0.5 and t not in lyr_tracks:
                warn.append("%s has no words." % t["name"])


# ----------------------------------------------------------------------------------------
# the model
# ----------------------------------------------------------------------------------------
def guess_tempo(info):
    m = info["meters"][0]
    b, bt = m["beats"], m["beatType"]
    # a beat in quarter notes
    compound = bt == 8 and b % 3 == 0 and b >= 6
    beat_q = 1.5 if compound else 4.0 / bt
    word = None
    if info.get("tempo_text"):
        mt = TEMPO_RE.search(info["tempo_text"])
        word = TEMPO_WORDS[mt.group(1).lower()] if mt else None
    per_beat = word or 80
    return round(per_beat * beat_q, 1), ("word" if word else "guess")


def build_model(info, parts, meta=None):
    meta = meta or {}
    warn = info["warnings"]
    order = play_order(info["struct"], warn)
    tracks = build_tracks(parts, [Fraction(b) for b in info["bar_starts"]], warn)
    if not tracks:
        raise ValueError("no sounding notes")
    share_words(tracks, warn)
    check(info, tracks, warn)
    tempo = info["tempo"]
    tempo_src = "score"
    if tempo is None:
        tempo, tempo_src = guess_tempo(info)
    m0 = info["meters"][0]
    model = {
        "title": meta.get("title") or info.get("movement") or info.get("work"),
        "composer": meta.get("composer") or info.get("composer"),
        "section": info.get("movement") if info.get("work") and info.get("movement") and info.get("movement") != info.get("work") else None,
        "lyricist": info.get("lyricist"),
        "meter": {"beats": m0["beats"], "beatType": m0["beatType"]},
        "fifths": info["keys"][0]["fifths"],
        "tempo": tempo, "tempoSource": tempo_src, "tempoText": info.get("tempo_text"),
        "bars": info["bars"],
        "barStarts": [f4(b) for b in info["bar_starts"]] + [f4(info["bar_end"])],
        "barLabels": info["bar_labels"] if info["bar_labels"] != [str(i + 1) for i in range(info["bars"])] else None,
        "meters": info["meters"] if len(info["meters"]) > 1 else None,
        "keys": info["keys"] if len(info["keys"]) > 1 else None,
        "tempos": info["tempos"] if len(info["tempos"]) > 1 else None,
        "playOrder": order if order != list(range(info["bars"])) else None,
        "repeats": _repeat_marks(info["struct"]),
        "verses": max([1] + [len(n.get("v", {})) + 1 for t in tracks for n in t["notes"] if n.get("v")]),
        "parts": tracks,
        "entrances": entrances(tracks, [float(b) for b in info["bar_starts"]]),
        "warnings": warn,
    }
    if m0["beatType"] == 1:
        model["display"] = {"scale": 0.5, "meter": {"beats": m0["beats"], "beatType": 2}, "tempo": round(tempo * 0.5, 1)}
    iss = info.get("bar_issues") or []
    if iss:
        model["check"] = iss[:300]
    model["quality"] = max(0, 100 - 8 * len(warn) - min(40, len(iss)))
    return {k: v for k, v in model.items() if v is not None}


def _repeat_marks(struct):
    out = []
    for k, s in enumerate(struct):
        d = {}
        if s.get("fwd"):
            d["fwd"] = True
        if s.get("back"):
            d["back"] = s["back"]
        if s.get("volta"):
            d["volta"] = sorted(s["volta"])
            if s.get("volta_start"):
                d["voltaStart"] = True
            if s.get("volta_stop"):
                d["voltaStop"] = True
        for a in ("segno", "coda", "tocoda", "dalsegno"):
            if s.get(a):
                d[a] = s[a]
        for a in ("dacapo", "fine"):
            if s.get(a):
                d[a] = True
        if d:
            d["bar"] = k
            out.append(d)
    return out or None


def entrances(tracks, starts):
    res = {}
    for t in tracks:
        if t["role"] != "voice":
            continue
        bars = set()
        for n in t["notes"]:
            if "midi" in n:
                bars.add(_bar([Fraction(x).limit_denominator(100000) for x in starts], Fraction(n["start"]).limit_denominator(100000)) + 1)
        res[t["id"]] = [b for b in sorted(bars) if b == 1 or (b - 1) not in bars]
    return res


def from_legacy(info, parts):
    """Bring the output of ly_reader.parse_lilypond into the shape build_model expects."""
    bs = [Fraction(b) for b in info["bar_starts"]]
    end = max([n["start"] + n["dur"] for p in parts for n in p["notes"]] + [bs[-1] if bs else Fraction(0)])
    nb = len(bs)
    if nb and end <= bs[-1]:
        end = bs[-1] + (bs[-1] - bs[-2] if nb > 1 else Fraction(4))
    m = info.get("meter") or {"beats": 4, "beatType": 4}
    fifths = info.get("fifths") or 0
    out_parts = []
    for p in parts:
        notes = []
        for n in p["notes"]:
            n = dict(n)
            n["verses"] = {"1": (n.pop("lyric", None), n.pop("syl", None) or "single")} if n.get("lyric") else {}
            n.pop("lyric", None); n.pop("syl", None)
            notes.append(n)
        out_parts.append({"id": p["id"], "name": p["name"], "notes": notes, "clefs": p["clefs"], "staves": 1})
    tempo = info.get("tempo")
    info2 = {"movement": info.get("movement"), "work": info.get("work"), "composer": None, "lyricist": None,
             "bars": nb, "bar_starts": bs, "bar_end": end,
             "meters": [{"bar": 0, "beats": m["beats"], "beatType": m["beatType"]}],
             "keys": [{"bar": 0, "fifths": fifths}], "tempos": [{"bar": 0, "beat": 0.0, "bpm": tempo}] if tempo else [],
             "tempo_text": None, "meter": m, "fifths": fifths, "struct": [{"num": str(i + 1)} for i in range(nb)],
             "bar_labels": [str(i + 1) for i in range(nb)], "warnings": list(info.get("warnings") or []), "tempo": tempo}
    return info2, out_parts


def convert_musicxml(path_or_bytes, meta=None):
    data = path_or_bytes if isinstance(path_or_bytes, (bytes, bytearray)) else read_bytes(path_or_bytes)
    info, parts = parse_musicxml(bytes(data))
    return build_model(info, parts, meta)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    mdl = convert_musicxml(sys.argv[1])
    out = Path(sys.argv[1]).with_suffix(".model.json")
    out.write_text(json.dumps(mdl, ensure_ascii=False, indent=1))
    print("%s  by %s" % (mdl.get("title"), mdl.get("composer")))
    print("%d bars, %d parts: %s" % (mdl["bars"], len(mdl["parts"]), ", ".join(p["name"] for p in mdl["parts"])))
    print("tempo %s (%s)  quality %s" % (mdl["tempo"], mdl["tempoSource"], mdl["quality"]))
    for w in mdl["warnings"]:
        print("  - " + w)
    print("wrote", out)
