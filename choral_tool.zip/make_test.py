import zipfile, os, pathlib
def part(pid, sign, line, octc, notes_xml):
    clef = f'<clef><sign>{sign}</sign><line>{line}</line>' + (f'<clef-octave-change>{octc}</clef-octave-change>' if octc else '') + '</clef>'
    return f'''<part id="{pid}"><measure number="0" implicit="yes"><attributes><divisions>2</divisions><key><fifths>-1</fifths></key><time><beats>4</beats><beat-type>4</beat-type></time>{clef}</attributes>
<direction><direction-type><words>Andante</words></direction-type><sound tempo="72"/></direction>
<note><rest/><duration>2</duration><voice>1</voice></note></measure>{notes_xml}</part>'''
def n(step,octv,dur,lyr=None,syl='single',tie=None,alter=0):
    t=''
    if tie=='start': t='<tie type="start"/>'
    if tie=='stop': t='<tie type="stop"/>'
    l = f'<lyric number="1"><syllabic>{syl}</syllabic><text>{lyr}</text></lyric>' if lyr else ''
    a = f'<alter>{alter}</alter>' if alter else ''
    return f'<note><pitch><step>{step}</step>{a}<octave>{octv}</octave></pitch><duration>{dur}</duration>{t}<voice>1</voice>{l}</note>'
def rest(dur): return f'<note><rest/><duration>{dur}</duration><voice>1</voice></note>'
def meas(i, body): return f'<measure number="{i}">{body}</measure>'
S = part('P1','G',2,None, meas(1, n('F',4,4,'A','begin')+n('G',4,4,'ve','end')) + meas(2, n('A',4,4,'ver','begin',tie='start')+n('A',4,2,None,tie='stop')+n('B',4,2,'um','end',alter=-1)))
A = part('P2','G',2,None, meas(1, rest(8)) + meas(2, n('C',4,8,'Ave','single')))
T = part('P3','G',2,'-1', meas(1, n('A',3,8,'Ave','single')) + meas(2, n('F',3,8)))
B = part('P4','F',4,None, meas(1, n('F',2,8,'Ave','single')) + meas(2, rest(8)))
xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 3.0 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">
<score-partwise version="3.0"><work><work-title>Ave verum</work-title></work><part-list>
<score-part id="P1"><part-name>Soprano</part-name></score-part><score-part id="P2"><part-name>Alto</part-name></score-part>
<score-part id="P3"><part-name>Tenor</part-name></score-part><score-part id="P4"><part-name>Bass</part-name></score-part></part-list>
{S}{A}{T}{B}</score-partwise>'''
# two voices in one part (SA on one staff), chord in vocal
two = f'''<?xml version="1.0"?><score-partwise version="3.0"><part-list><score-part id="P1"><part-name>Choir</part-name></score-part></part-list>
<part id="P1"><measure number="1"><attributes><divisions>1</divisions><time><beats>3</beats><beat-type>4</beat-type></time><clef><sign>G</sign><line>2</line></clef></attributes>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>3</duration><voice>1</voice></note><backup><duration>3</duration></backup>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>3</duration><voice>2</voice></note></measure></part></score-partwise>'''
root = pathlib.Path('testdata'); (root/'dump/images/a/ab').mkdir(parents=True, exist_ok=True)
def mxl(name, data):
    with zipfile.ZipFile(root/'dump/images/a/ab'/name,'w') as z:
        z.writestr('META-INF/container.xml','<container><rootfiles><rootfile full-path="score.xml"/></rootfiles></container>')
        z.writestr('score.xml', data)
mxl('Ave_verum.mxl', xml); mxl('Two_voices.mxl', two); mxl('Modern.mxl', xml); mxl('Nolic.mxl', xml); mxl('Ave_verum_low.mxl', xml.replace('<fifths>-1</fifths>','<fifths>-3</fifths>'))
wiki = """<mediawiki xmlns="http://www.mediawiki.org/xml/export-0.10/">
<page><title>William Byrd</title><ns>0</ns><revision><text>William Byrd (1543-1623) English composer</text></revision></page>
<page><title>Thomas Tallis</title><ns>0</ns><revision><text>born 1505, died 1585</text></revision></page>
<page><title>John Rutter</title><ns>0</ns><revision><text>John Rutter (born 1945)</text></revision></page>
<page><title>Ave verum corpus (William Byrd)</title><ns>0</ns><revision><text>==Editions==
*{{PDF|Ave_verum.pdf|Score}} {{MusicXML|Ave verum.mxl|MusicXML}} {{Editor|Jane Doe|2005-01-01}} (CPDL #01234)
**{{Copy|CPDL}}
*{{MusicXML|Ave_verum_low.mxl}} {{Editor|Jane Doe|2006}} (CPDL #01235) Transposed down a tone {{Copy|CPDL}}
*{{PDF|x.pdf|Score}} [[Media:Nolic.mxl]] {{Editor|Anon Ed|2010-01-01}} (CPDL #05555)
</text></revision></page>
<page><title>If ye love me (Thomas Tallis)</title><ns>0</ns><revision><text>*{{Edition|[[Media:Two_voices.mxl]]}} {{Editor|Bob Smith|2001}} {{Copy|CC-BY}} (CPDL #00009)</text></revision></page>
<page><title>Some piece (John Rutter)</title><ns>0</ns><revision><text>*{{MusicXML|Modern.mxl}} {{Editor|Z|2001}} {{Copy|CPDL}}</text></revision></page>
</mediawiki>"""
(root/'current.xml').write_text(wiki, encoding='utf-8')
