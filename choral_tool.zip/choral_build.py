#!/usr/bin/env python3
"""
choral_build.py - turn the CPDL (ChoralWiki) WikiTeam dump into Tutti "note models".

Standard library only (Python 3.9+). Works on Windows, Mac and Linux.

WHAT IT DOES
  1. Reads the wiki page text (cpdlorg_wiki-20201112-current.xml) and finds, for every
     work page, each MusicXML edition (.mxl / .musicxml) with its editor, CPDL number
     and licence.
  2. Keeps an edition only if
        - the licence is the CPDL Licence, public domain, CC0 or CC-BY, AND
        - the composer is established public domain (died 1955 or earlier, or anonymous /
          traditional / chant).
     Everything else is listed in the reports, never converted.
  3. Opens each kept MusicXML file (from the extracted dump) and writes
        choral/models/<id>.json     one note model per edition
        choral/catalog.json         index of all models
        choral/ATTRIBUTION.md       editors, sources, licences
        choral/reports/*.txt|csv    what was kept, what was refused and why

THE MUSICXML FILES THEMSELVES ARE NEVER COPIED INTO THE OUTPUT.

USAGE (see README.txt for the Windows walk-through)
  python choral_build.py --xml cpdlorg_wiki-20201112-current.xml --images C:\\cpdl\\dump --out choral --limit 50
  python choral_build.py --xml ... --images ... --out choral            (the full run)
  python choral_build.py --xml ... --scan-only --out choral             (reports only, no dump needed)

The script is resumable: models that already exist are skipped (use --force to redo).
"""
import argparse
import csv
import io
import json
import os
import re
import sys
import traceback
import unicodedata
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile
try:
    import ly_reader
except ImportError:          # script copied without ly_reader.py
    ly_reader = None
import choral_read
read_musicxml_bytes = choral_read.read_bytes      # kept for lieder_build.py
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from pathlib import Path

DUMP_LABEL_DEFAULT = "2020-11-12"
MAX_DEATH_YEAR = 1955          # died on or before this year => public domain (life + 70)
ASSUME_BORN_BEFORE = 1850      # no death year found: born before this => treated as PD
ALLOWED = {"cpdl", "pd", "cc0", "cc-by"}
LICENCE_URLS = {
    "cpdl": "https://www.cpdl.org/wiki/index.php/ChoralWiki:CPDL",
    "pd": None,
    "cc0": "https://creativecommons.org/publicdomain/zero/1.0/",
    "cc-by": "https://creativecommons.org/licenses/by/3.0/",
}
ANON_RE = re.compile(r"^(anon|anonymous|unknown|traditional|trad\.?|folk|plainchant|plainsong|"
                     r"gregorian( chant)?|chant|ambrosian chant|mozarabic chant|various|"
                     r"unknown composer|anonymous composer)\b", re.I)

# ----------------------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------------------
def slug(text, maxlen=60):
    t = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    t = re.sub(r"[^a-zA-Z0-9]+", "-", t).strip("-").lower()
    return t[:maxlen].strip("-") or "work"


def norm_filename(name):
    n = urllib.parse.unquote(name).strip().replace(" ", "_")
    return n[:1].upper() + n[1:] if n else n


def local(tag):
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def child(el, name):
    for c in el:
        if local(c.tag) == name:
            return c
    return None


def children(el, name):
    return [c for c in el if local(c.tag) == name]


def text_of(el, name, default=None):
    c = child(el, name)
    return (c.text or "").strip() if c is not None and c.text else default


# ----------------------------------------------------------------------------------------
# wiki dump reading
# ----------------------------------------------------------------------------------------
def read_pages(xml_path):
    """Return {title: wikitext} for main-namespace pages."""
    pages = {}
    ctx = ET.iterparse(xml_path, events=("end",))
    for _, el in ctx:
        if local(el.tag) != "page":
            continue
        title = text_of(el, "title", "")
        ns = text_of(el, "ns", "0")
        rev = child(el, "revision")
        txt = ""
        if rev is not None:
            t = child(rev, "text")
            txt = (t.text or "") if t is not None else ""
        if ns == "0" and title:
            pages[title] = txt
        el.clear()
    return pages


FILE_RE = re.compile(r"(?:\||:|\[\[|=|/)\s*([^|\]\[{}\n=]+?\.(?:mxl|musicxml|ly))\b", re.I)
EDITOR_RE = re.compile(r"\{\{\s*Editor\s*\|\s*([^|}\n]+)", re.I)
EDITOR2_RE = re.compile(r"\bEditor\s*:\s*(?:\[\[)?([^\n|\]\[{}(),;]+)", re.I)
CPDLNO_RE = re.compile(r"(?:CPDL\s*#\s*|\{\{\s*CPDLno\s*\|\s*)(\d+)", re.I)
COPY_RE = re.compile(r"\{\{\s*(?:Copy|Copyright|Licen[cs]e)\s*\|\s*([^|}\n]*)", re.I)
BARE_TEMPLATE_RE = re.compile(r"\{\{\s*([^|}\n]+?)\s*[|}]")
TITLE_RE = re.compile(r"^(?P<title>.+?)\s*\((?P<composer>[^()]+)\)\s*$")


def norm_licence(raw):
    """Map a raw licence string to a key: cpdl, pd, cc0, cc-by, or rejected/unknown labels."""
    if raw is None:
        return "unknown"
    s = raw.strip().lower()
    if not s:
        return "unknown"
    toks = set(re.split(r"[^a-z0-9]+", s)) - {""}
    if "cpdl" in toks or "choralwiki" in toks:
        return "cpdl"
    if re.search(r"cc[\s_-]?0\b|cc[\s_-]?zero|zero", s):
        return "cc0"
    if "public" in toks or s in {"pd", "pubdom"} or "pd" in toks:
        return "pd"
    if "personal" in toks:
        return "personal"
    if "cc" in toks or "creative" in toks:
        if "sa" in toks or "sharealike" in toks:
            return "cc-by-sa"
        if "nc" in toks or "noncommercial" in toks:
            return "cc-by-nc"
        if "nd" in toks or "noderivs" in toks:
            return "cc-by-nd"
        if "by" in toks or "attribution" in toks:
            return "cc-by"
    return "other:" + s[:40]


def free_text_licence(block):
    """Licence named in plain text (no {{Copy|..}} template). Conservative."""
    m = re.search(r"\bCC[\s_-]?0\b", block, re.I)
    if m:
        return "cc0"
    m = re.search(r"\bCC[\s_-]?BY((?:[\s_-]?(?:SA|NC|ND))*)\b", block, re.I)
    if m:
        return "cc-by" if not m.group(1).strip() else "cc-by" + re.sub(r"[\s_]+", "-", m.group(1).lower())
    if re.search(r"public[\s_]+domain", block, re.I):
        return "pd"
    return "unknown"


def edition_note(block):
    """Plain-text note from an edition block (key / transposition remarks), templates and links removed."""
    t = re.sub(r"\{\{[^{}]*\}\}", " ", block)
    t = re.sub(r"\[\[(?:[^|\]]*\|)?([^\]]*)\]\]", r"\1", t)
    t = re.sub(r"\[https?://\S+\s*([^\]]*)\]", r"\1", t)
    t = re.sub(r"[*#:;]+", " ", t)
    t = re.sub(r"\(CPDL\s*#\d+\)", " ", t, flags=re.I)
    t = re.sub(r"\s+", " ", t).strip(" -,;")
    return t[:240]


def split_blocks(text):
    """Split page text into edition blocks: a new block starts at a top-level bullet or heading."""
    blocks, cur = [], []
    for line in text.splitlines():
        top = (line.startswith("*") and not line.startswith("**")) or line.startswith("=")
        if top and cur:
            blocks.append("\n".join(cur))
            cur = []
        cur.append(line)
    if cur:
        blocks.append("\n".join(cur))
    return blocks


def find_editions(title, text, stats):
    """Yield edition dicts for each MusicXML file referenced on a work page."""
    out = []
    for block in split_blocks(text):
        files = []
        for m in FILE_RE.finditer(block):
            f = re.sub(r"^(?:media|file|image)\s*:\s*", "", m.group(1).strip(), flags=re.I)
            if f not in files:
                files.append(f)
        if not files:
            continue
        for tm in BARE_TEMPLATE_RE.finditer(block):
            stats["templates"][tm.group(1).strip().lower()[:30]] += 1
        em = EDITOR_RE.search(block) or EDITOR2_RE.search(block)
        editor = em.group(1).strip().strip("[]'") if em else ""
        nm = CPDLNO_RE.search(block)
        cm = COPY_RE.search(block)
        raw_lic = cm.group(1).strip() if cm else None
        lic = norm_licence(raw_lic) if cm else free_text_licence(block)
        stats["licence_raw"][(raw_lic if cm else "(free text)" + lic)] += 1
        xml_files = [f for f in files if not f.lower().endswith(".ly")]
        for f in (xml_files or files):
            out.append({
                "page": title, "file": f, "editor": editor,
                "cpdl_number": nm.group(1) if nm else None,
                "licence": lic, "licence_raw": raw_lic, "block": block[:600], "note": edition_note(block),
            })
    return out


YEARS_RE = re.compile(r"\(?\b(?:c\.?\s*)?(\d{3,4})\s*[-\u2013\u2014]\s*(?:c\.?\s*)?(\d{3,4})\b\)?")
DIED_RE = re.compile(r"\b(?:died|d\.)\s*:?\s*(?:[^\n]{0,30}?)(\d{4})\b", re.I)
BORN_RE = re.compile(r"\b(?:born|b\.)\s*:?\s*(?:[^\n]{0,30}?)(\d{4})\b", re.I)


def composer_status(name, pages, overrides):
    """Return (True|False|None, reason). None = could not establish."""
    if name in overrides:
        return bool(overrides[name]), "override"
    if ANON_RE.match(name.strip()):
        return True, "anonymous/traditional/chant"
    for key in (name, name.replace("_", " ")):
        txt = pages.get(key)
        if txt:
            head = txt[:4000]
            m = YEARS_RE.search(head)
            if m:
                a, b = int(m.group(1)), int(m.group(2))
                if a < b:
                    return (b <= MAX_DEATH_YEAR), f"died {b}"
            d = DIED_RE.search(head)
            if d:
                y = int(d.group(1))
                return (y <= MAX_DEATH_YEAR), f"died {y}"
            bm = BORN_RE.search(head)
            if bm and int(bm.group(1)) < ASSUME_BORN_BEFORE:
                return True, f"born {bm.group(1)}"
    return None, "no dates found"


# ----------------------------------------------------------------------------------------
# MusicXML -> note model
# ----------------------------------------------------------------------------------------
def convert_file(path, meta):
    """Return a note-model dict for one edition (meta carries title, composer, source...)."""
    if str(path).lower().endswith(".ly"):
        if ly_reader is None:
            raise ValueError("ly_reader.py is missing next to choral_build.py")
        raw = Path(path).read_bytes()
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            text = raw.decode("latin-1")
        info, parts = ly_reader.parse_lilypond(text)
        model = choral_read.build_model(*choral_read.from_legacy(info, parts), meta=None)
    else:
        model = choral_read.convert_musicxml(path)
    # catalogue facts win over what the file says about itself
    model["id"] = meta["id"]
    model["title"] = meta["title"] or model.get("title")
    model["composer"] = meta["composer"] or model.get("composer")
    model["language"] = meta.get("language")
    model["source"] = meta["source"]
    model["work_group"] = meta.get("work_group")
    model["edition_note"] = meta.get("edition_note") or None
    model["_movement"] = model.get("section") or None
    model["_warnings"] = list(model.get("warnings") or [])
    return model


def worker(task):
    path, meta, out_dir, force = task
    out_file = Path(out_dir) / "models" / (meta["id"] + ".json")
    if out_file.exists() and not force:
        return {"id": meta["id"], "status": "skipped"}
    try:
        model = convert_file(path, meta)
        model.pop("_movement", None)
        warns = model.pop("_warnings", [])
        out_file.write_text(json.dumps(model, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        return {"id": meta["id"], "status": "ok", "warnings": warns, "file": str(path)}
    except Exception as e:  # noqa
        return {"id": meta["id"], "status": "error", "error": "%s: %s" % (type(e).__name__, e),
                "file": str(path)}


# ----------------------------------------------------------------------------------------
# main
# ----------------------------------------------------------------------------------------
def index_images(images_dir):
    idx = {}
    n = 0
    for dp, _, fns in os.walk(images_dir):
        for fn in fns:
            if fn.lower().endswith((".mxl", ".musicxml", ".ly")):
                idx.setdefault(norm_filename(fn), Path(dp) / fn)
                n += 1
    return idx, n


def write_csv(path, rows, header):
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--xml", required=True, help="the wiki pages XML (cpdlorg_wiki-20201112-current.xml)")
    ap.add_argument("--images", help="folder where the dump's .mxl files were extracted")
    ap.add_argument("--out", default="choral", help="output folder (default: choral)")
    ap.add_argument("--dump-label", default=DUMP_LABEL_DEFAULT, help="date of the dump, e.g. 2020-11-12")
    ap.add_argument("--limit", type=int, default=0, help="convert only the first N kept editions (test run)")
    ap.add_argument("--scan-only", action="store_true", help="only write the reports")
    ap.add_argument("--force", action="store_true", help="redo models that already exist")
    ap.add_argument("--jobs", type=int, default=0, help="parallel workers (default: CPU count, max 8)")
    ap.add_argument("--composer-overrides", help='JSON file {"Composer Name": true|false} to settle composers by hand')
    a = ap.parse_args()

    out = Path(a.out)
    (out / "models").mkdir(parents=True, exist_ok=True)
    (out / "reports").mkdir(parents=True, exist_ok=True)
    overrides = {}
    if a.composer_overrides:
        overrides = json.loads(Path(a.composer_overrides).read_text(encoding="utf-8"))

    print("Reading wiki pages ...")
    pages = read_pages(a.xml)
    print("  %d pages" % len(pages))

    stats = {"templates": Counter(), "licence_raw": Counter()}
    editions, comp_cache = [], {}
    pages_with_editions = 0
    for title, text in pages.items():
        if title.startswith(("Category:", "Template:", "Help:", "ChoralWiki:")):
            continue
        m = TITLE_RE.match(title)
        if not m:
            continue
        eds = find_editions(title, text, stats)
        if not eds:
            continue
        pages_with_editions += 1
        for e in eds:
            e["work_title"], e["composer"] = m.group("title").strip(), m.group("composer").strip()
            editions.append(e)
    print("  %d work pages with MusicXML editions, %d editions" % (pages_with_editions, len(editions)))

    kept, refused = [], []
    unresolved = Counter()
    for e in editions:
        reasons = []
        if e["licence"] not in ALLOWED:
            reasons.append("licence:" + e["licence"])
        comp = e["composer"]
        if re.search(r"\b(arr|arranged|arrangement)\b", comp, re.I):
            reasons.append("arrangement-in-title")
        else:
            if comp not in comp_cache:
                comp_cache[comp] = composer_status(comp, pages, overrides)
            ok, why = comp_cache[comp]
            if ok is None:
                reasons.append("composer-unresolved")
                unresolved[comp] += 1
            elif not ok:
                reasons.append("composer-in-copyright:" + why)
        (refused if reasons else kept).append((e, reasons))

    # ---- scan reports
    rep = out / "reports"
    write_csv(rep / "kept_editions.csv",
              [[e["page"], e["file"], e["editor"], e["cpdl_number"] or "", e["licence"]] for e, _ in kept],
              ["page", "file", "editor", "cpdl_number", "licence"])
    write_csv(rep / "refused_editions.csv",
              [[e["page"], e["file"], e["editor"], e["licence"], e["licence_raw"] or "", ";".join(r)] for e, r in refused],
              ["page", "file", "editor", "licence", "licence_raw", "reasons"])
    with open(rep / "composers_unresolved.txt", "w", encoding="utf-8") as f:
        f.write("Composers whose death year could not be found. Add them to a JSON file such as\n"
                '{"Name": true, "Other Name": false} (true = public domain) and pass --composer-overrides.\n\n')
        for c, n in unresolved.most_common():
            f.write("%5d  %s\n" % (n, c))
    with open(rep / "scan_report.txt", "w", encoding="utf-8") as f:
        f.write("Wiki pages: %d\nWork pages with MusicXML: %d\nEditions found: %d\nKept: %d\nRefused: %d\n\n"
                % (len(pages), pages_with_editions, len(editions), len(kept), len(refused)))
        why = Counter(r.split(":")[0] if r.startswith("composer-in") else r for _, rs in refused for r in rs)
        f.write("Refusal reasons:\n")
        for k, v in why.most_common():
            f.write("  %6d  %s\n" % (v, k))
        f.write("\nMost common templates on edition lines:\n")
        for k, v in stats["templates"].most_common(60):
            f.write("  %6d  {{%s}}\n" % (v, k))
        f.write("\nLicence strings found:\n")
        for k, v in stats["licence_raw"].most_common(60):
            f.write("  %6d  %s\n" % (v, k))
        f.write("\nSample kept edition blocks:\n")
        for e, _ in kept[:8]:
            f.write("-----\n%s\n" % e["block"])
        f.write("\nSample refused edition blocks (licence unknown):\n")
        shown = 0
        for e, r in refused:
            if "licence:unknown" in r and shown < 8:
                f.write("-----\n%s\n" % e["block"])
                shown += 1
    print("Reports written to %s" % rep)
    print("  kept %d, refused %d (see reports/scan_report.txt)" % (len(kept), len(refused)))
    if a.scan_only:
        return

    if not a.images:
        sys.exit("--images is required unless --scan-only is used")
    print("Indexing extracted files in %s ..." % a.images)
    img_idx, n_files = index_images(a.images)
    print("  %d MusicXML files found" % n_files)

    # ---- assign ids and metadata
    per_page = defaultdict(list)
    for e, _ in kept:
        per_page[e["page"]].append(e)
    tasks, missing, used_ids = [], [], set()
    for page, eds in per_page.items():
        for k, e in enumerate(eds):
            path = img_idx.get(norm_filename(e["file"]))
            if not path:
                missing.append([page, e["file"]])
                continue
            base = slug(e["work_title"] + " " + e["composer"].split()[-1] if e["composer"].split() else e["work_title"])
            sid = "%s-%s" % (base, e["cpdl_number"]) if e["cpdl_number"] else "%s-%d" % (base, k + 1)
            while sid in used_ids:
                sid += "x"
            used_ids.add(sid)
            title = e["work_title"]
            if len(eds) > 1:
                stem = re.sub(r"[_]+", " ", Path(e["file"]).stem).strip()
                if stem and stem.lower() != title.lower():
                    title = "%s \u2014 %s" % (title, stem)
            licence = e["licence"]
            meta = {
                "id": sid, "title": title, "composer": e["composer"], "language": None,
                "work_group": slug(e["work_title"] + " " + e["composer"], 80), "edition_note": e["note"],
                "source": {
                    "work_page": "https://www.cpdl.org/wiki/index.php/" + urllib.parse.quote(e["page"].replace(" ", "_"), safe="_()',"),
                    "editor": e["editor"], "cpdl_number": e["cpdl_number"],
                    "licence": licence, "licence_url": LICENCE_URLS.get(licence), "dump": a.dump_label,
                },
            }
            tasks.append((str(path), meta, str(out), a.force))
    write_csv(rep / "missing_files.csv", missing, ["page", "file"])
    if a.limit:
        tasks = tasks[:a.limit]
    print("Converting %d editions (%d referenced files were not in the extracted folder) ..." % (len(tasks), len(missing)))

    jobs = a.jobs or min(8, os.cpu_count() or 2)
    results = []
    if jobs > 1 and len(tasks) > 20:
        with ProcessPoolExecutor(max_workers=jobs) as ex:
            for i, r in enumerate(ex.map(worker, tasks, chunksize=20), 1):
                results.append(r)
                if i % 500 == 0:
                    print("  %d / %d" % (i, len(tasks)))
    else:
        for i, t in enumerate(tasks, 1):
            results.append(worker(t))
            if i % 500 == 0:
                print("  %d / %d" % (i, len(tasks)))
    errs = [r for r in results if r["status"] == "error"]
    write_csv(rep / "conversion_errors.csv", [[r["id"], r["file"], r["error"]] for r in errs], ["id", "file", "error"])
    write_csv(rep / "conversion_warnings.csv",
              [[r["id"], r.get("file", ""), " | ".join(r["warnings"])] for r in results if r.get("warnings")],
              ["id", "file", "warnings"])
    print("  ok %d, skipped %d, errors %d" % (sum(r["status"] == "ok" for r in results),
                                              sum(r["status"] == "skipped" for r in results), len(errs)))

    # ---- catalog + attribution from the model files on disk
    catalog, editors = [], Counter()
    for fp in sorted((out / "models").glob("*.json")):
        try:
            m = json.loads(fp.read_text(encoding="utf-8"))
        except Exception:
            continue
        entry = {k: m.get(k) for k in ("id", "title", "composer", "language", "meter", "tempo", "fifths", "bars", "entrances", "source", "work_group", "edition_note")}
        entry["parts"] = [{"id": p["id"], "name": p["name"], **({"clef": p["clef"]} if p.get("clef") else {}), "notes": []}
                          for p in m.get("parts", [])]
        entry["model_path"] = "models/%s.json" % m["id"]
        catalog.append(entry)
        ed = (m.get("source") or {}).get("editor")
        if ed:
            editors[ed] += 1
    groups = defaultdict(list)
    for c in catalog:
        if c.get("work_group"):
            groups[c["work_group"]].append(c)
    multi = {g: v for g, v in groups.items() if len({x.get("fifths") for x in v}) > 1}
    with open(rep / "key_variants.txt", "w", encoding="utf-8") as f:
        f.write("Works with editions in more than one key signature (%d works)\n\n" % len(multi))
        for g, v in sorted(multi.items()):
            f.write("%s\n" % v[0]["title"].split(" \u2014 ")[0])
            for x in v:
                f.write("   %-40s fifths=%s  editor=%s  %s\n" % (x["id"], x.get("fifths"), (x.get("source") or {}).get("editor"), x.get("edition_note") or ""))
    print("  %d works have editions in more than one key (reports/key_variants.txt)" % len(multi))
    (out / "catalog.json").write_text(json.dumps(catalog, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    lic = Counter(c["source"]["licence"] for c in catalog)
    with open(out / "ATTRIBUTION.md", "w", encoding="utf-8") as f:
        f.write("Attribution and provenance - choral note models\n\nGenerated from %d works.\n\n" % len(catalog))
        f.write("Each `models/<id>.json` is a note model (pitches, rhythms, lyrics, structure) of a public-domain\n"
                "composition, derived from a MusicXML edition published on the Choral Public Domain Library\n"
                "(CPDL, https://www.cpdl.org). The edition files are not redistributed. Each model's `source` block\n"
                "names its work page, editor, CPDL number and licence.\n\n")
        f.write("Source: WikiTeam archive of CPDL, https://archive.org/details/wiki-cpdlorg_wiki-with-files (dump of %s).\n\n" % a.dump_label)
        f.write("Licences: " + ", ".join("%s (%d)" % (k, v) for k, v in lic.most_common()) + "\n\n")
        f.write("## Editors whose editions these models derive from\n\n")
        for ed, n in editors.most_common():
            f.write("- %s (%d)\n" % (ed, n))
    print("Done. %d models in the catalog. Upload the '%s' folder." % (len(catalog), out))


if __name__ == "__main__":
    main()
