#!/usr/bin/env python3
"""
scan_pdf.py - turn a PDF (or photo) of a score into a Tutti note model, the way PlayScore does,
using Audiveris, a free music-recognition program, on YOUR computer.

   python scan_pdf.py "C:\\scores\\Ave verum.pdf"
   python scan_pdf.py "C:\\scores\\Ave verum.pdf" --title "Ave verum corpus" --composer "William Byrd"
   python scan_pdf.py folder_of_pdfs\\ --out scanned

Per score it writes, in the --out folder (default "scanned"):
   <name>.mxl            the MusicXML Audiveris found (open it in MuseScore to correct it)
   <name>.model.json     the Tutti note model (same shape as the CPDL models)
   <name>.check.txt      what to check: bars where a part does not add up, missing words, odd ranges

Honest limits (true of every scanner, PlayScore included): it reads clean PRINTED music well and
handwriting or poor photocopies badly; lyrics in Latin or other languages are the weakest part;
it always needs a person to check the result. Only scan music you have the right to copy.

Audiveris: free, https://github.com/Audiveris/audiveris (Windows installer in "Releases").
If it is not found automatically, give its path:   --audiveris "C:\\Program Files\\Audiveris\\Audiveris.exe"
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

import choral_read

CANDIDATES = [
    r"C:\Program Files\Audiveris\Audiveris.exe",
    r"C:\Program Files\Audiveris\bin\Audiveris.bat",
    r"C:\Program Files (x86)\Audiveris\Audiveris.exe",
    "/Applications/Audiveris.app/Contents/MacOS/Audiveris",
    "/opt/audiveris/bin/Audiveris",
    "/usr/bin/audiveris",
]
INPUT_EXT = (".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif")


def find_audiveris(given=None):
    for c in [given, os.environ.get("AUDIVERIS")] + CANDIDATES:
        if c and Path(c).exists():
            return str(c)
    for name in ("Audiveris", "audiveris", "Audiveris.bat"):
        p = shutil.which(name)
        if p:
            return p
    return None


def run_audiveris(exe, src, work, pages=None, timeout=1800):
    """Run Audiveris on one file; return the list of .mxl files it produced."""
    work.mkdir(parents=True, exist_ok=True)
    before = {p: p.stat().st_mtime for p in work.rglob("*.mxl")}
    cmd = [exe, "-batch", "-transcribe", "-export", "-output", str(work)]
    if pages:
        cmd += ["-sheets", pages]          # sheet numbers, e.g. 1-3 (see Audiveris CLI guide)
    cmd.append(str(src))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise RuntimeError("Audiveris took longer than %d minutes and was stopped." % (timeout // 60))
    except OSError as e:
        raise RuntimeError("Could not start Audiveris (%s)." % e)
    out = [p for p in work.rglob("*.mxl") if p not in before or p.stat().st_mtime > before.get(p, 0)]
    if not out:
        tail = (proc.stdout + "\n" + proc.stderr).strip().splitlines()[-6:]
        raise RuntimeError("Audiveris produced no MusicXML (exit code %s). Last lines:\n  %s" % (proc.returncode, "\n  ".join(tail)))
    return sorted(out)


def write_check(path, name, model):
    L = ["Check list for: %s" % name, "=" * 60, ""]
    L.append("Parts found: %s" % ", ".join("%s (%s)" % (p["name"], p.get("voice", "-")) for p in model["parts"]))
    L.append("Bars: %d   Time signature: %d/%d   Tempo: %s (%s)" % (
        model["bars"], model["meter"]["beats"], model["meter"]["beatType"], model["tempo"], model.get("tempoSource")))
    L.append("")
    chk = model.get("check") or []
    if chk:
        L.append("BARS THAT DO NOT ADD UP (most likely a misread note or rhythm; look at these first):")
        by_bar = {}
        for c in chk:
            by_bar.setdefault(c["bar"] + 1, []).append(c)
        for bar in sorted(by_bar):
            L.append("  bar %-4d %s" % (bar, "; ".join("%s has %s beats, expected %s%s" % (
                c["part"], c["found"], c["expected"], " (empty)" if c["kind"] == "empty" else "") for c in by_bar[bar])))
        L.append("")
    if model.get("warnings"):
        L.append("OTHER THINGS TO CHECK:")
        for w in model["warnings"]:
            L.append("  - " + w)
        L.append("")
    if not chk and not model.get("warnings"):
        L.append("Nothing looked wrong to the automatic checks. That does NOT mean it is perfect:")
        L.append("listen through once with the score open.")
    L.append("")
    L.append("Words: if the words are wrong, correct them in MuseScore (open the .mxl) and re-import.")
    Path(path).write_text("\n".join(L), encoding="utf-8")


def scan_one(exe, src, out, meta, pages=None, keep_work=False):
    src = Path(src)
    work = out / ("_work_" + re.sub(r"\W+", "_", src.stem))
    try:
        mxls = run_audiveris(exe, src, work, pages)
    except Exception:
        shutil.rmtree(work, ignore_errors=True)
        raise
    done = []
    for i, mx in enumerate(mxls):
        stem = src.stem if len(mxls) == 1 else "%s.%d" % (src.stem, i + 1)
        dst = out / (stem + ".mxl")
        shutil.copyfile(mx, dst)
        model = choral_read.convert_musicxml(str(dst), meta=meta)
        model["source"] = {"kind": "scan", "engine": "Audiveris", "file": src.name}
        (out / (stem + ".model.json")).write_text(json.dumps(model, ensure_ascii=False, indent=1), encoding="utf-8")
        write_check(out / (stem + ".check.txt"), stem, model)
        done.append((stem, model))
    if not keep_work:
        shutil.rmtree(work, ignore_errors=True)
    return done


def main():
    ap = argparse.ArgumentParser(description="PDF/photo of a score -> MusicXML + Tutti note model (needs Audiveris)")
    ap.add_argument("input", help="a PDF or image, or a folder of them")
    ap.add_argument("--out", default="scanned")
    ap.add_argument("--audiveris", help="path to Audiveris if it is not found automatically")
    ap.add_argument("--title")
    ap.add_argument("--composer")
    ap.add_argument("--pages", help="only these sheets, e.g. 1-3 (see the Audiveris CLI guide)")
    ap.add_argument("--keep-work", action="store_true", help="keep Audiveris's own project files")
    a = ap.parse_args()
    exe = find_audiveris(a.audiveris)
    if not exe:
        print("Audiveris was not found.\n  1. Download the installer for your system from https://github.com/Audiveris/audiveris/releases\n"
              "  2. Install it, then run this again (or add  --audiveris \"path\\to\\Audiveris.exe\").")
        return 2
    src = Path(a.input)
    files = sorted(p for p in src.rglob("*") if p.suffix.lower() in INPUT_EXT) if src.is_dir() else [src]
    if not files:
        print("No PDF or image files found in", src)
        return 2
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    meta = {k: v for k, v in (("title", a.title), ("composer", a.composer)) if v}
    bad = 0
    for f in files:
        t0 = time.time()
        print("Scanning %s ..." % f.name, flush=True)
        try:
            for stem, m in scan_one(exe, f, out, meta, a.pages, a.keep_work):
                print("  %s: %d bars, %d parts, %d things to check  (%.0f s)" % (
                    stem, m["bars"], len(m["parts"]), len(m.get("check") or []) + len(m.get("warnings") or []), time.time() - t0))
        except Exception as e:
            bad += 1
            print("  FAILED: %s" % e)
    print("Done. Open the .check.txt files first." if not bad else "Done, %d file(s) failed." % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
