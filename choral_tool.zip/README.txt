CHORAL NOTE MODEL BUILDER - Windows walk-through
=================================================

You need: Python 3.9 or newer (python.org/downloads; tick "Add python.exe to PATH" in the installer)
          and 7-Zip (7-zip.org). About 40 GB free disk space for the full run. Nothing else to install.

Keep choral_build.py, choral_read.py and ly_reader.py together in one folder (choral_read.py reads the MusicXML, ly_reader.py reads LilyPond .ly editions), e.g. C:\cpdl\tool, and open that folder in Command Prompt
(type cmd in the folder's address bar).

STEP 1 - small check first (about 5 minutes, only a 23 MB download)
  1. Go to https://archive.org/download/wiki-cpdlorg_wiki-with-files/
  2. Download cpdlorg_wiki-20201112-current.xml.7z (23 MB).
  3. Right-click it > 7-Zip > Extract to "C:\cpdl\xml\". You get one .xml file.
  4. Run (change the file name if yours differs):
       python choral_build.py --xml C:\cpdl\xml\cpdlorg_wiki-20201112-current.xml --scan-only --out C:\cpdl\choral
  5. Send Claude the file C:\cpdl\choral\reports\scan_report.txt (and composers_unresolved.txt).
     This shows which editions would be kept and why others are refused. DO THIS BEFORE THE BIG DOWNLOAD,
     because the script reads CPDL's page markup and I could not check that against a real page.

STEP 2 - the big download (17.7 GB)
  Download cpdlorg_wiki-20201112-wikidump.7z from the same page (a browser works; it takes a while).

STEP 3 - extract only the MusicXML files (saves disk space)
  In Command Prompt:
    "C:\Program Files\7-Zip\7z.exe" x C:\Users\YOU\Downloads\cpdlorg_wiki-20201112-wikidump.7z -oC:\cpdl\dump *.mxl *.ly -r
  (7-Zip still reads the whole archive, so this takes a long time, but it only writes the .mxl files.)

STEP 4 - test run on 50 pieces
    python choral_build.py --xml C:\cpdl\xml\cpdlorg_wiki-20201112-current.xml --images C:\cpdl\dump --out C:\cpdl\choral --limit 50
  Send Claude: C:\cpdl\choral\catalog.json (it is small until the full run), three files from
  C:\cpdl\choral\models\, and reports\conversion_errors.csv.

STEP 5 - the full run
    python choral_build.py --xml C:\cpdl\xml\cpdlorg_wiki-20201112-current.xml --images C:\cpdl\dump --out C:\cpdl\choral
  It can be stopped (Ctrl+C) and started again; finished models are skipped.
  Result: C:\cpdl\choral\  with catalog.json, models\, ATTRIBUTION.md and reports\.

COMPOSERS THE SCRIPT COULD NOT SETTLE
  reports\composers_unresolved.txt lists composers whose death year is not on their wiki page.
  Make a file overrides.json like {"Some Composer": true, "Other Composer": false} (true = public domain,
  died 1955 or earlier) and add:  --composer-overrides overrides.json   then run again.

WHAT IS KEPT
  Editions under the CPDL Licence, public domain, CC0 or CC-BY, by composers who died in 1955 or earlier
  (or are anonymous / traditional / chant). Everything else is listed in reports\refused_editions.csv with the reason.
  Editions that have a MusicXML file are read from that; if an edition has only a LilyPond (.ly) file, ly_reader.py reads that.
  Editions with only PDF/MIDI are not converted (reports\refused or missing). The source files themselves are never copied into the output.
  Extract the LilyPond files too in step 3:  add  *.ly  after *.mxl  in the 7z command.
  The Polovetsian Dances (Borodin, IMSLP) exception is not in this dump and is added separately.


WHAT THE READER NOW DOES (choral_read.py)
  Repeats, first/second endings, D.C./D.S./Fine/coda   -> "playOrder" (the bars in the order they are sung)
  Printed bar numbers (pick-up bars, bar 0, 1a/1b)      -> "barLabels"; real bar positions -> "barStarts"
  Changes of time signature, key and tempo              -> "meters", "keys", "tempos"
  Voices by name (Soprano/Cantus/Superius/Tenor 2/Bassus...) or by pitch; SATB on two staves; divisi chords
  All verses of the words ("v" on each note); words written once are shared with lines that move together
  Alla breve (2/1) editions are shown with halved values ("display")
  A "warnings" list and a "check" list (bar + part) of anything that looks misread, in every model.
  Quick self-test (needs nothing):   python test_reader.py
  One file on its own:               python choral_read.py "C:\scores\piece.mxl"

PDF OR PHOTO OF A SCORE -> PLAYABLE (like PlayScore)   scan_pdf.py
  1. Install Audiveris (free): https://github.com/Audiveris/audiveris/releases  (Windows installer).
  2. Run:   python scan_pdf.py "C:\scores\Ave verum.pdf" --title "Ave verum corpus" --composer "William Byrd"
  3. In the "scanned" folder you get the .mxl (open it in MuseScore to correct it), the note model (.model.json)
     and a .check.txt that lists the bars to look at first.
  Only scan music you have the right to copy. Scanning is never perfect: always check the result.
  NOTE: scan_pdf.py follows Audiveris's documented command line; it was tested against a stand-in
  program, not the real Audiveris, so send Claude the first real error message if one appears.
